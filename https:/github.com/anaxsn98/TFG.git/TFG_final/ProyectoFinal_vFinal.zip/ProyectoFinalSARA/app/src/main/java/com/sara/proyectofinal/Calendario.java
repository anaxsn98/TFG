package com.sara.proyectofinal;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.github.sundeepk.compactcalendarview.CompactCalendarView;
import com.github.sundeepk.compactcalendarview.domain.Event;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.sara.proyectofinal.modelo.entidad.Evento;
import com.sara.proyectofinal.modelo.negocio.GestorPlanta;
import com.sara.proyectofinal.modelo.servicio.GoRestPlantaApiService;
import com.sara.proyectofinal.singleton.TokenSingletone;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Calendario extends AppCompatActivity {
    private CompactCalendarView calendarView;
    private Toolbar toolbar;
    private DialogoGif dialogoGif;
    private BottomNavigationView bottomNavigationView;
    private ImageView imtPrevious,imgNext;
    private TextView txtMesAño;
    private SimpleDateFormat dateFormatForMonth = new SimpleDateFormat("MMMM- yyyy", Locale.getDefault());
    private ProgressDialog mDefaultDialog;
    private List<Evento> eventos;
    private TokenSingletone tokenSingletone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendario);

        //controlador = Controlador.getInstance();
        imgNext = findViewById(R.id.imgNext);
        imtPrevious = findViewById(R.id.imtPrevious);
        calendarView = findViewById(R.id.calendarView);
        txtMesAño = findViewById(R.id.txtMesAño);
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("");
        bottomNavigationView = findViewById(R.id.bottomNavigationBar);
        getEventos();

        setSupportActionBar(toolbar);

        DateFormat dateFormat = new SimpleDateFormat("MMMM-yyyy");
        Date date = new Date();
        Log.d("Month",dateFormat.format(date));
        String mes = dateFormat.format(date);
        txtMesAño.setText(mes);

        calendarView.setListener(new CompactCalendarView.CompactCalendarViewListener() {
            @Override
            public void onDayClick(Date dateClicked) {
                List<Event> events = calendarView.getEvents(dateClicked);
                Log.d("Events: ", "Day was clicked: " + dateClicked + " with events " + events);
            }

            @Override
            public void onMonthScroll(Date firstDayOfNewMonth) {
                txtMesAño.setText(dateFormatForMonth.format(firstDayOfNewMonth));
                Log.d("Events: ", "Month was scrolled to: " + firstDayOfNewMonth);
            }
        });
        imtPrevious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calendarView.scrollLeft();
            }
        });

        imgNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calendarView.scrollRight();

                // compactCalendarView.showNextMonth();
            }
        });

        bottomNavigationView.setSelectedItemId(R.id.calendario);
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Intent intent;
                int id = item.getItemId();
                bottomNavigationView.setItemIconTintList(null);
                switch(id){
                    case R.id.planta:
                        intent = new Intent( getApplicationContext(),MainActivity.class);
                        startActivity(intent);
                        finish();
                        return true;
                    case R.id.misPlantas:
                        intent = new Intent( getApplicationContext(),MisPlantasActivity.class);
                        startActivity(intent);
                        finish();
                        return true;
                    case R.id.calendario:
                        intent = new Intent( getApplicationContext(),Calendario.class);
                        startActivity(intent);
                        finish();
                        return true;
                }
                return true;
            }
        });
    }

    /**
     * Recoge el menu que hemos creado en un xml y lo infla en la vista
     * Devuelve verdadero en caasao de que pueda ejecytar el proceso
     *
     * @param menu
     * @return true
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_bar, menu);
        return true;
    }

    /**
     * Recoge el id de los items que hemos creado en el menu
     * Si el id corresponde al de carrito se hará el proceso correspondiente
     *
     * @param item recoge los items de las opciones del menu.
     * @return boolean
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.ayuda) {//abrir un activity
            Intent intent = new Intent( this,Ayuda1.class);
            startActivity(intent);
            finish();
        }
        if (id == R.id.menu_castellano) { //cambiar de idioma la aplicación
            Configuration config = getBaseContext().getResources().getConfiguration();
            Locale locale = new Locale("es","ES");
            Locale.setDefault(locale);
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
            recreate();
        }
        if (id == R.id.menu_ingles) {//cambiar de idioma de la aplicación
            Configuration config = getBaseContext().getResources().getConfiguration();
            Locale locale = new Locale("en","GB");
            Locale.setDefault(locale);
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
            recreate();
        }
        if (id == R.id.menu_usuario) { //abrir un activity
            Intent intent = new Intent( this, UsuarioActivity.class);
            startActivity(intent);
            finish();
        }
        if (id == R.id.logout) {//abrir un activity
            Intent intent = new Intent( this, LoginActivity.class);
            startActivity(intent);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * Poner eventos en el calendario
     */
    public void setEventosInCalendar(){
        Calendar currentCalender = Calendar.getInstance(Locale.getDefault());
        if(eventos != null && eventos.size() <1)
            return;

        currentCalender.setTime(new Date());
        currentCalender.set(Calendar.DAY_OF_MONTH, 1);
        Date firstDayOfMonth = currentCalender.getTime();

        for (Evento e: eventos) {
            currentCalender.setTime(firstDayOfMonth);
            for (String s: e.getMeses()) {
                String[] partes = s.split("/");
                currentCalender.set(Calendar.MONTH, Integer.parseInt(partes[1])-1);
                currentCalender.add(Calendar.DATE, Integer.parseInt(partes[0]));
                setToMidnight(currentCalender);
                calendarView.addEvent(new Event(Color.parseColor(e.getColor()), currentCalender.getTimeInMillis()));
            }

        }
    }

    /**
     *  Método rest recoge los eventos de una planta y los pone en el calendario
     */
    public void getEventos(){
        mostrarEspera();
        tokenSingletone = TokenSingletone.getInstance();
        System.out.println(tokenSingletone);
        GoRestPlantaApiService goRestPlantaApiService =
                GestorPlanta.getInstance().getGoRestPlantaApiService();

        Call<List<Evento>> call = goRestPlantaApiService.getEventos(tokenSingletone.getToken(),
                tokenSingletone.getId());

        call.enqueue(new Callback<List<Evento>>() {
            @Override
            public void onResponse(Call<List<Evento>> call, Response<List<Evento>> response) {
                if (response.isSuccessful()) {
                    Log.d("Eventos Planta Actual", "busqueda hecha");
                    eventos = response.body();

                    if(eventos != null)
                        setEventosInCalendar();
                } else {

                    cancelarEspera();

                }

                cancelarEspera();
            }

            @Override
            public void onFailure(Call<List<Evento>> call, Throwable t) {
                Log.d("Eventos Planta Actual", t.toString());
                cancelarEspera();

            }
        });
    }
    /**
     * Método que muestra un dialogo personalizado
     */
    public void mostrarEspera() {
        dialogoGif = new DialogoGif();
        dialogoGif.setContext(Calendario.this);
        dialogoGif.mostrarDialogo();
    }

    /**
     * Método que termina con el dialogo
     */
    public void cancelarEspera(){
        dialogoGif.ocultarDialogo();
    }

    /**
     * Set hora del calendario a 0
     * @param calendar
     */
    private void setToMidnight(Calendar calendar) {
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
    }
}