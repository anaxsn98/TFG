package com.sara.proyectofinal;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.os.CountDownTimer;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.Switch;

import com.sara.proyectofinal.modelo.entidad.Planta;
import com.sara.proyectofinal.modelo.negocio.GestorPlanta;
import com.sara.proyectofinal.modelo.servicio.GoRestPlantaApiService;
import com.sara.proyectofinal.singleton.PlantaSingletone;
import com.sara.proyectofinal.singleton.TokenSingletone;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Fragment_control#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Fragment_control extends Fragment {
    private View vista;
    private Switch fragment_Riego,fragment_luz,fragment_Ventilador;
    private PlantaSingletone plantaSingletone;
    private DialogoGif dialogoGif;
    private TokenSingletone tokenSingletone;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Fragment_control() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Fragment_control.
     */
    // TODO: Rename and change types and number of parameters
    public static Fragment_control newInstance(String param1, String param2) {
        Fragment_control fragment = new Fragment_control();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ArrayAdapter<CharSequence> adapter;

        vista = inflater.inflate(R.layout.fragment_control, container, false);
        fragment_Riego = vista.findViewById(R.id.fragment_Riego);
        fragment_luz = vista.findViewById(R.id.fragment_luz);
        fragment_Ventilador = vista.findViewById(R.id.fragment_Ventilador);



        adapter = ArrayAdapter.createFromResource(getActivity().getApplicationContext(), R.array.desplegableIntervalo, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        //setOnCheckedChangeListener cuando detecten un cambio que modifique la planta en la base
        //de datos
        fragment_Riego.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    recargar();
                    plantaSingletone = PlantaSingletone.getInstance();
                    plantaSingletone.getPlanta().setRegar(1);
                    actualizarPlantaActual();
                    cambiarSwitch(fragment_Riego);
                }

            }
        });

        fragment_luz.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    recargar();
                    plantaSingletone = PlantaSingletone.getInstance();
                    plantaSingletone.getPlanta().setLuz(1);
                    actualizarPlantaActual();
                    cambiarSwitch(fragment_luz);
                }

            }
        });

        fragment_Ventilador.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    recargar();
                    plantaSingletone = PlantaSingletone.getInstance();
                    plantaSingletone.getPlanta().setVentilador(1);
                    actualizarPlantaActual();
                    cambiarSwitch(fragment_Ventilador);
                }

            }
        });

        return vista;
    }

    public void recargar(){
        plantaSingletone = PlantaSingletone.getInstance();
        plantaSingletone.getPlanta().setRegar(0);
        plantaSingletone.getPlanta().setLuz(0);
        plantaSingletone.getPlanta().setVentilador(0);
    }

    /**
     * Método para cambiar el estado del swich a los 40 segundos
     */
    public void cambiarSwitch(Switch switchh){
        new CountDownTimer(30000, 1000) {

            public void onTick(long millisUntilFinished) {
            }

            @Override
            public void onFinish() {
                switchh.setChecked(false);
            }

        }.start();
    }

    /**
     *  Servicio res que actualiza la planta actual
     */
    public void actualizarPlantaActual(){
        mostrarEspera();
        tokenSingletone = TokenSingletone.getInstance();
        System.out.println(tokenSingletone);
        GoRestPlantaApiService goRestUsuarioApiService =
                GestorPlanta.getInstance().getGoRestPlantaApiService();

        Call<Planta> call = goRestUsuarioApiService.modificarPlanta(tokenSingletone.getToken(), tokenSingletone.getId(),plantaSingletone.getPlanta());

        call.enqueue(new Callback<Planta>() {
            //Este método se ejecutará cuando el servidor HTTP nos responda
            //satisfactoriamente
            @Override
            public void onResponse(Call<Planta> call, Response<Planta> response) {
                if (response.isSuccessful()) {
                    Log.d("ActualizarPlantaActual", "busqueda hecha");
                    cancelarEspera();
                    recargar();

                } else {
                    Log.d("ActualizarPlantaActual", response.code() + " " + response.message());

                }

                cancelarEspera();
            }

            @Override
            public void onFailure(Call<Planta> call, Throwable t) {
                Log.d("ActualizarPlantaActual", t.toString());
                cancelarEspera();
            }
        });
    }
    /**
     * Método que muestra un dialogo personalizado
     */
    public void mostrarEspera() {
        dialogoGif = new DialogoGif();
        dialogoGif.setContext(getActivity());
        dialogoGif.mostrarDialogo();
    }

    /**
     * Método que termina con el dialogo
     */
    public void cancelarEspera(){
        dialogoGif.ocultarDialogo();
    }
}