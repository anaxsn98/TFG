package com.sara.proyectofinal.singleton;

import com.sara.proyectofinal.modelo.entidad.Planta;

public class PlantaSingletone {
    private static PlantaSingletone instance;
    private Planta planta;

    //Lo hacemos privado para que nadie entre en la clase,
    //porque si lo hago publico se pueden hacer news del objeto

    /**
     * Constructor del objeto privado para que nadie entre en la clase,
     * porque si lo hago publico se pueden hacer news del objeto
     */
    private PlantaSingletone() {

        super();
    }

    /**
     * getInstance es como los getBeans
     * queremos que nos devuelva la instancia del objeto, no puede ser dinamico
     * tiene que ser estático porque es el método que te devuelve el objeto que es la instancia
     * La primera vez que llamamos al objeto no existe dede el principio del programa
     * Para no sobrecargar la memoria
     * @return instancia de la clase
     */
    public static PlantaSingletone getInstance() {
        if (instance == null) {
            instance = new PlantaSingletone();
        }
        return instance;
    }

    /**
     * Getter de planta
     * @return
     */
    public Planta getPlanta() {
        return planta;
    }

    /**
     * Setter de planta
     * @param planta
     */
    public void setPlanta(Planta planta) {
        this.planta = planta;
    }
}
