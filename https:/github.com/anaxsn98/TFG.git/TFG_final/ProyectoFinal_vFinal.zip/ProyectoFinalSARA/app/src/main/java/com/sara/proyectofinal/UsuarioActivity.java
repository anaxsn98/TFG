package com.sara.proyectofinal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.util.Patterns;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.budiyev.android.codescanner.CodeScanner;
import com.budiyev.android.codescanner.CodeScannerView;
import com.budiyev.android.codescanner.DecodeCallback;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.zxing.Result;
import com.sara.proyectofinal.modelo.entidad.AltaUsuarioDto;
import com.sara.proyectofinal.modelo.entidad.Usuario;
import com.sara.proyectofinal.modelo.negocio.GestorUsuario;
import com.sara.proyectofinal.modelo.servicio.GoRestUsuarioApiService;
import com.sara.proyectofinal.singleton.TokenSingletone;

import java.util.Locale;
import java.util.regex.Pattern;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UsuarioActivity extends AppCompatActivity {
    private BottomNavigationView bottomNavigationView;
    private Toolbar toolbar;
    private DialogoGif dialogoGif;
    private TokenSingletone tokenSingletone;
    private TextView usuario_editEmail,usuairoError,eliminarUsuairo;
    private EditText usuario_editNombreUsuario,usuario_editPassword, usuario_editPasswordConfirmar,usuario_editInvernadero;
    private Button btnGuardar;
    private CodeScanner mCodeScanner;
    private CodeScannerView usuario_scanner_view;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usuario);

        bottomNavigationView = findViewById(R.id.bottomNavigationBar);
        toolbar = findViewById(R.id.usuario_toolbar);
        btnGuardar = findViewById(R.id.btnGuardar);
        usuario_editNombreUsuario = findViewById(R.id.usuario_editNombreUsuario);
        usuario_editEmail = findViewById(R.id.usuario_editEmail);
        usuario_editPassword = findViewById(R.id.usuario_editPassword);
        usuario_editPasswordConfirmar = findViewById(R.id.usuario_editPasswordConfirmar);
        eliminarUsuairo = findViewById(R.id.eliminarUsuairo);
        usuairoError = findViewById(R.id.UsuairoError);
        usuario_editInvernadero = findViewById(R.id.usuario_editInvernadero);
        usuario_scanner_view = findViewById(R.id.usuario_scanner_view);
        mCodeScanner = new CodeScanner(this, usuario_scanner_view);


        buscarUsuairo();
        toolbar.setTitle("");
        setSupportActionBar(toolbar);
        bottomNavigationView.setSelectedItemId(R.id.misPlantas);

        tokenSingletone = TokenSingletone.getInstance();

        mCodeScanner.setDecodeCallback(new DecodeCallback() {
            @Override
            public void onDecoded(@NonNull final Result result) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        usuario_editInvernadero.setText( result.getText().toString());
                    }
                });
            }
        });
        usuario_scanner_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mCodeScanner.startPreview();
            }
        });

        eliminarUsuairo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialogoEliminarUsuario();
            }
        });
        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(controlDeErorres( usuario_editNombreUsuario.getText().toString(),  usuario_editEmail.getText().toString(), usuario_editPassword.getText().toString(), usuario_editPasswordConfirmar.getText().toString(),usuario_editInvernadero.getText().toString())){
                    AltaUsuarioDto user = new AltaUsuarioDto();
                    user.setCorreo(usuario_editEmail.getText().toString());
                    user.setNombre(usuario_editNombreUsuario.getText().toString());
                    user.setPwd(usuario_editPassword.getText().toString());
                    user.setPwd2(usuario_editPasswordConfirmar.getText().toString());
                    user.setCodigo_invernadero(usuario_editInvernadero.getText().toString());

                    dialogoMdificarUsuario(user);

                }

            }
        });
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Intent intent;
                int id = item.getItemId();
                switch(id){
                    case R.id.planta:
                        intent = new Intent( getApplicationContext(),MainActivity.class);
                        startActivity(intent);
                        finish();
                        return true;
                    case R.id.misPlantas:
                        intent = new Intent( getApplicationContext(),MisPlantasActivity.class);
                        startActivity(intent);
                        finish();
                        return true;
                    case R.id.calendario:
                        intent = new Intent( getApplicationContext(),Calendario.class);
                        startActivity(intent);
                        finish();
                        return true;
                }
                return true;
            }
        });


    }

    /**
     * Recoge el menu que hemos creado en un xml y lo infla en la vista
     * Devuelve verdadero en caasao de que pueda ejecytar el proceso
     *
     * @param menu
     * @return true
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_bar, menu);
        //menu.findItem(R.id.UsuarioActivity).setVisible(true);
        return true;
    }

    /**
     * Recoge el id de los items que hemos creado en el menu
     * Si el id corresponde al de carrito se abrirá el Main Activity del carrito
     *
     * @param item recoge los items de las opciones del menu.
     * @return item ,Devuelve el id del item que se haya seleccionado.
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.ayuda) {
            Intent intent = new Intent( this,Ayuda1.class);
            startActivity(intent);
            finish();
        }
        if (id == R.id.menu_castellano) {
            Configuration config = getBaseContext().getResources().getConfiguration();
            Locale locale = new Locale("es","ES");
            Locale.setDefault(locale);
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
            recreate();
        }
        if (id == R.id.menu_ingles) {
            Configuration config = getBaseContext().getResources().getConfiguration();
            Locale locale = new Locale("en","GB");
            Locale.setDefault(locale);
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
            recreate();
        }
        if (id == R.id.menu_usuario) {
            Intent intent = new Intent( this, UsuarioActivity.class);
            startActivity(intent);
            finish();
        }
        if (id == R.id.logout) {
            Intent intent = new Intent( this, LoginActivity.class);
            startActivity(intent);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     *  Método que abre un dialogo para preguntar al usuario si quiere dar de baja
     *  la planta actual y crear una nueva
     */
    public void dialogoEliminarUsuario(){

        AlertDialog.Builder builder = new AlertDialog.Builder(UsuarioActivity.this);
        builder.setMessage("¿Está seguro que desea eliminar su cuenta? Al realizar esta acción se borrarán " +
                "todas sus plantas");

        //En este caso si que voy a poner un listener al boton, ya que
        //quiero cerrar la actividad
        builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                eliminarUsuairo();
            }
        });

        //Es este caso tambien meto el boton en caso de que no quiera
        //hacer la accion
        builder.setNegativeButton("Cancelar", null);

        AlertDialog dialog = builder.create();
        //Establecemos que no cancele el dialogo si pulsa fuera del cuadro
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();



    }
    public void dialogoMdificarUsuario(AltaUsuarioDto user){

        AlertDialog.Builder builder = new AlertDialog.Builder(UsuarioActivity.this);
        builder.setMessage("¿Está seguro que desea guardar los gambios?");
        //En este caso si que voy a poner un listener al boton, ya que
        //quiero cerrar la actividad
        builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                modificarUsuairo(user);

            }
        });

        //Es este caso tambien meto el boton en caso de que no quiera
        //hacer la accion
        builder.setNegativeButton("Cancelar", null);

        AlertDialog dialog = builder.create();
        //Establecemos que no cancele el dialogo si pulsa fuera del cuadro
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();



    }
    /**
     *  Método rest para buscar datos de un usuario por id
     */
    public void buscarUsuairo(){
        mostrarEspera();
        tokenSingletone = TokenSingletone.getInstance();

        GoRestUsuarioApiService goRestUsuarioApiService =
                GestorUsuario.getInstance().getGoRestUserApiService();

        Call<Usuario> call = goRestUsuarioApiService.getPersonaById(tokenSingletone.getToken(),
                tokenSingletone.getId());

        call.enqueue(new Callback<Usuario>() {
            //Este método se ejecutará cuando el servidor HTTP nos responda
            //satisfactoriamente
            @Override
            public void onResponse(Call<Usuario> call, Response<Usuario> response) {
                if (response.isSuccessful()) {
                    Log.d("Buscar Usuairo", "busqueda hecha");
                    Usuario usuario = response.body();
                    usuario_editNombreUsuario.setText(usuario.getNombre());
                    usuario_editEmail.setText(usuario.getCorreo());
                    usuario_editInvernadero.setText(usuario.getCodigo_invernadero());

                    cancelarEspera();

                } else {
                    Log.d("Buscar Usuairo", response.code() + " " + response.message());

                }

                cancelarEspera();
            }

            @Override
            public void onFailure(Call<Usuario> call, Throwable t) {
                Log.d("Buscar Usuairo", t.toString());
                cancelarEspera();
            }
        });
    }
    /**
     *  Método rest para modificar usuario por id
     */
    public void modificarUsuairo(AltaUsuarioDto user){
        mostrarEspera();
        tokenSingletone = TokenSingletone.getInstance();

        GoRestUsuarioApiService goRestUsuarioApiService =
                GestorUsuario.getInstance().getGoRestUserApiService();

        Call<Usuario> call = goRestUsuarioApiService.modificarPersona(tokenSingletone.getToken(),
                tokenSingletone.getId(),user);

        call.enqueue(new Callback<Usuario>() {
            @Override
            public void onResponse(Call<Usuario> call, Response<Usuario> response) {
                if (response.isSuccessful()) {
                    Log.d("Modificar Usuairo", "busqueda hecha");
                    Usuario usuario = response.body();
                    usuario_editNombreUsuario.setText(usuario.getNombre());
                    usuario_editEmail.setText(usuario.getCorreo());
                    usuario_editInvernadero.setText(usuario.getCodigo_invernadero());

                    cancelarEspera();

                } else {
                    Log.d("Modificar Usuairo", response.code() + " " + response.message());

                }

                cancelarEspera();
            }

            @Override
            public void onFailure(Call<Usuario> call, Throwable t) {
                Log.d("Modificar Usuairo", t.toString());
                cancelarEspera();
                respuestaError("usuario o correo duplicado");
            }
        });
    }
    /**
     *  Llamada a servicio rest para eliminar un usuario por id y todas sus plantas
     */
    public void eliminarUsuairo(){
        mostrarEspera();
        tokenSingletone = TokenSingletone.getInstance();
        System.out.println(tokenSingletone);
        GoRestUsuarioApiService goRestUsuarioApiService =
                GestorUsuario.getInstance().getGoRestUserApiService();

        Call<Void> call = goRestUsuarioApiService.eliminarUsuario(tokenSingletone.getToken(),
                tokenSingletone.getId());

        call.enqueue(new Callback<Void>() {
            //Este método se ejecutará cuando el servidor HTTP nos responda
            //satisfactoriamente
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {

                Log.d("Eliminar Usuario", "busqueda hecha");

                cancelarEspera();

                Intent mainActivity = new Intent(UsuarioActivity.this, LoginActivity.class);
                startActivity(mainActivity);
                finish();

            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Log.d("Eliminar Usuario", t.toString());
                cancelarEspera();
            }
        });
    }

    /**
     * Método que comprueba que el emailsea valido y los campos no esten vacíos o que haya más de 6
     * caracteres
     * @param nombre nombre de usuario
     * @param email email del usuario
     * @param pwd contraseña del usuario
     * @param pwd2 confirmación de contraseña del usuario
     * @return false si hay algún error true en caso de que no haya error
     */
    public boolean controlDeErorres(String nombre, String email,String pwd,String pwd2,String codigo_invernadero){
        Pattern pattern = Patterns.EMAIL_ADDRESS;
        String mensaje="";
        if (nombre.equals("") || email.equals("") || codigo_invernadero.equals("")){
            mensaje = "Campos vacios";
            respuestaError(mensaje);
            Log.d("Login", mensaje);
            return false;
        }
        if (nombre.length() < 6 || email.length() < 6 || codigo_invernadero.length() < 6){
            mensaje = "Menos que 6 caracteres";
            Log.d("Login", mensaje);
            respuestaError(mensaje);
            return false;
        }

        if(!pwd.equals("") || !pwd2.equals("") ){
            if(pwd.length() < 6 || pwd2.length() < 6){
                mensaje = "Menos que 6 caracteres";
                Log.d("Login", mensaje);
                respuestaError(mensaje);
                return false;
            }
        }

        if(!pattern.matcher(email).matches()){
            mensaje="Email no válido";
            Log.d("Login", mensaje);
            respuestaError(mensaje);
            return false;
        }
        if(!pwd.equals(pwd2)){
            mensaje="Las contraseñas no coinciden";
            Log.d("Login", mensaje);
            respuestaError(mensaje);
            return false;
        }
        return true;
    }


    /**
     * Método para mostrar un mensaje de error durante 5 segundos
     */
    public void respuestaError(String mensaje){
        new CountDownTimer(5000, 1000) {

            public void onTick(long millisUntilFinished) {
                usuairoError.setText(mensaje);

            }

            @Override
            public void onFinish() {
                usuairoError.setText("");
            }

        }.start();
    }
    /**
     * Método que muestra un dialog personalizado
     */
    public void mostrarEspera() {
        dialogoGif = new DialogoGif();
        dialogoGif.setContext(UsuarioActivity.this);
        dialogoGif.mostrarDialogo();
    }

    /**
     * Método que termina con el dialog
     */
    public void cancelarEspera(){
        dialogoGif.ocultarDialogo();
    }
    @Override
    public void onResume() {
        super.onResume();
        mCodeScanner.startPreview();
    }

}