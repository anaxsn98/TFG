package com.sara.proyectofinal;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.sara.proyectofinal.modelo.entidad.Planta;
import com.sara.proyectofinal.modelo.entidad.Tiposplanta;
import com.sara.proyectofinal.modelo.negocio.GestorPlanta;
import com.sara.proyectofinal.modelo.servicio.GoRestPlantaApiService;
import com.sara.proyectofinal.singleton.TokenSingletone;

import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ConfiguracionPlantaPersonalizadaActivity extends AppCompatActivity {
    private Spinner spinner_riego,spinner_luz,spinner_ventilador;
    private EditText editMinVentilación,editMinLuz,editMililitros;
    private TextView nombre_planta_personalizada;
    private Button buttonEntrar;
    private TokenSingletone tokenSingletone;
    private ProgressDialog mDefaultDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_configuracion_planta_personalizada);
        ArrayAdapter<CharSequence> adapter;
        Planta planta;

        buttonEntrar = findViewById(R.id.buttonEntrar);
        editMinVentilación=findViewById(R.id.editMinVentilación);
        editMinLuz = findViewById(R.id.editMinLuz);
        editMililitros = findViewById(R.id.editMililitros);
        spinner_riego = findViewById(R.id.spinner_riego);
        spinner_luz = findViewById(R.id.spinner_luz);
        spinner_ventilador = findViewById(R.id.spinner_ventilador);
        nombre_planta_personalizada = findViewById(R.id.nombre_planta_personalizada);


        planta = (Planta) getIntent().getSerializableExtra("Planta");

        if(planta != null && !planta.getNombre().equals("")){
            nombre_planta_personalizada.setText(planta.getNombre());
        }
        adapter = ArrayAdapter.createFromResource(this, R.array.desplegableIntervalo,
                android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_riego.setAdapter(adapter);
        spinner_luz.setAdapter(adapter);
        spinner_ventilador.setAdapter(adapter);

        buttonEntrar.setOnClickListener(new View.OnClickListener() { //registrar planta
            @Override
            public void onClick(View view) {
                planta.setIntervaloTiempoVentilador(spinner_ventilador.getSelectedItemPosition());
                planta.setIntervaloTiempoRiego(spinner_riego.getSelectedItemPosition());
                planta.setIntervaloTiempoLuz(spinner_luz.getSelectedItemPosition());

                planta.setRegar(1);
                planta.setLuz(1);
                planta.setVentilador(1);

                if(!editMinVentilación.getText().toString().equals(""))
                    planta.setMinVentilador(Integer.parseInt(editMinVentilación.getText().toString()));
                if(!editMinLuz.getText().toString().equals(""))
                    planta.setMinLuz(Integer.parseInt(editMinLuz.getText().toString()));
                if(!editMililitros.getText().toString().equals(""))
                    planta.setMl(Integer.parseInt(editMililitros.getText().toString()));

                registroPlanta(planta);
            }
        });

    }


    /**
     * llamada al servicio que de alta planta
     * @param p planta que se quiere dar de alta
     */
    public void registroPlanta(Planta p){
        mostrarEspera();

        GoRestPlantaApiService goRestPlantaApiService =
                GestorPlanta.getInstance().getGoRestPlantaApiService();

        //recogemos la instancia del token para la autorización
        tokenSingletone = TokenSingletone.getInstance();

        Call<Planta> call = goRestPlantaApiService.altaPlanta(tokenSingletone.getToken(),
                tokenSingletone.getId(),p);

        call.enqueue(new Callback<Planta>() {
            @Override
            public void onResponse(Call<Planta> call, Response<Planta> response) {
                if (response.isSuccessful()) {
                    cancelarEspera();

                    Intent mainActivity = new Intent(
                            ConfiguracionPlantaPersonalizadaActivity.this,
                            MainActivity.class);
                    startActivity(mainActivity);
                    finish();
                } else {
                    Log.d("Alta planta", response.code() + " " + response.message());
                    return;
                }

                cancelarEspera();
            }

            @Override
            public void onFailure(Call<Planta> call, Throwable t) {
                Log.d("Alta planta", t.toString());
                cancelarEspera();
            }
        });
    }
    /**
     * Método que muestra un dialogo personalizado
     */
    public void mostrarEspera() {
        mDefaultDialog = new ProgressDialog(this);
        // El valor predeterminado es la forma de círculos pequeños
        mDefaultDialog.setProgressStyle (ProgressDialog.STYLE_SPINNER);
        mDefaultDialog.setMessage("Solicitando datos ...");
        mDefaultDialog.setCanceledOnTouchOutside(false);// Por defecto true
        mDefaultDialog.show();
    }

    /**
     * Método que termina con el dialogo
     */
    public void cancelarEspera(){
        mDefaultDialog.cancel();
    }

    /**
     * Este método es llamado luego de onCreate().
     *
     * Comprueba el idioma seleccionado en la aplicación y lo aplica en la vista correspondiente
     */
    @Override
    protected void onStart() {
        super.onStart();
        Configuration config = getBaseContext().getResources().getConfiguration();
        Locale locale = getResources().getConfiguration().locale;
        Locale.setDefault(locale);
        config.locale = locale;
        getBaseContext().getResources().updateConfiguration(config, getBaseContext()
                .getResources()
                .getDisplayMetrics());
    }
}