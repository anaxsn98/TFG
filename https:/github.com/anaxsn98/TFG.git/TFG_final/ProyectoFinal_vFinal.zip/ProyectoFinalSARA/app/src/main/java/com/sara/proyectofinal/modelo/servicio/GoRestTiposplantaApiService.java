package com.sara.proyectofinal.modelo.servicio;

import com.sara.proyectofinal.modelo.entidad.Tiposplanta;
import com.sara.proyectofinal.modelo.entidad.Usuario;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface GoRestTiposplantaApiService {
    //Para poder hacer uso del servicio hay que logarse en la página y generar
    //un token de autenticación, luego hay que incluirlo en la cabecera, dentro
    //del parametros Authorization

    /**
     * Servicio que devuelve una lista de todos los tipos de plantas que hay en la base de datos
     * @param token token de autrorización
     * @return lista de tipos de plantas y codigo de respuesta 200 ok o un 404 not
     *         found si no se ha encontrado ningún tipoplanta
     */
    @GET("tipoplanta")
    Call<List<Tiposplanta>> getAllTipoPlanta(@Header("Authorization") String token);

}
