package com.sara.proyectofinal.modelo.entidad;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.HashSet;
import java.util.List;

/*Clase para mostrar los eventos de las plantas*/
public class Evento implements Serializable {
	private String titulo;
	private String color;
	private String mes1;/* Mes Inicial de creación de la planta */
	private HashSet<String> meses;


	public void initHashSet() {
		meses = new HashSet<String>();
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getMes1() {
		return mes1;
	}

	public void setMes1(String mes1) {
		this.mes1 = mes1;
	}

	public HashSet<String> getMeses() {
		return meses;
	}

	public void setMeses(HashSet<String> meses) {
		this.meses = meses;
	}
}
