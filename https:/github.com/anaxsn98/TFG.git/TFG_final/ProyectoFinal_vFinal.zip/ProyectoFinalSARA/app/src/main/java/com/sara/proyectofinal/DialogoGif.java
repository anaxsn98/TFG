package com.sara.proyectofinal;

import android.app.Activity;
import android.app.Application;
import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.ColorDrawable;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatDialog;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.sara.proyectofinal.R;

/**
 * Diálogo personalizado
 */
public class DialogoGif {
    private Dialog dialog;
    Context context;

    /**
     * Constructor al que le pasamos el contexto en el que hay que poner el dialogo
     * @param context contexto
     */
    public void setContext(Context context) {
        this.context = context;
    }

    /**
     * Método que muestra en la vista el dialogo
     */
    public void mostrarDialogo() {
        dialog = new Dialog(this.context);
        dialog.setContentView(R.layout.dialogo_gift);
        dialog.create();
        dialog.show();
    }

    /**
     * Método que oculta el dialogo de la vista
     */
    public void ocultarDialogo() {
        dialog.dismiss();

    }


}