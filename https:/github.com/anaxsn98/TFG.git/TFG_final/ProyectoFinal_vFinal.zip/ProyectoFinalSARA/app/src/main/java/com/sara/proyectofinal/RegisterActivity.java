package com.sara.proyectofinal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.budiyev.android.codescanner.CodeScanner;
import com.budiyev.android.codescanner.CodeScannerView;
import com.budiyev.android.codescanner.DecodeCallback;
import com.google.zxing.Result;
import com.sara.proyectofinal.modelo.entidad.AltaUsuarioDto;
import com.sara.proyectofinal.modelo.entidad.JwtResponse;
import com.sara.proyectofinal.modelo.negocio.GestorPlanta;
import com.sara.proyectofinal.modelo.negocio.GestorTiposplanta;
import com.sara.proyectofinal.modelo.negocio.GestorUsuario;
import com.sara.proyectofinal.modelo.servicio.GoRestUsuarioApiService;
import com.sara.proyectofinal.singleton.TokenSingletone;

import java.util.Locale;
import java.util.regex.Pattern;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends AppCompatActivity {
    private Button btnRegistro;
    private TokenSingletone tokenSingletone;
    private TextView txtInicio,registroError;
    private EditText editEmail,editNombreUsuario,editPassword, editPasswordConfirmar,editInvernadero;
    private ImageView imgEN,imgES;
    private CodeScanner mCodeScanner;
    private CodeScannerView scannerView;
    private DialogoGif dialogoGif;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Inicializar gestores
        GestorPlanta.getInstance().inicializar();
        GestorUsuario.getInstance().inicializar();
        GestorTiposplanta.getInstance().inicializar();

        setContentView(R.layout.activity_register);
        btnRegistro = findViewById(R.id.btnRegistro);
        editNombreUsuario = findViewById(R.id.editNombreUsuario);
        editEmail = findViewById(R.id.editEmail);
        editPassword = findViewById(R.id.editPassword);
        editPasswordConfirmar = findViewById(R.id.editPasswordConfirmar);
        txtInicio = findViewById(R.id.txtInicio);
        registroError = findViewById(R.id.RegistroError);
        editInvernadero = findViewById(R.id.editInvernadero);
        scannerView = findViewById(R.id.scanner_view);
        mCodeScanner = new CodeScanner(this, scannerView);
        imgEN = findViewById(R.id.imgEN);
        imgES = findViewById(R.id.imgES);

        imgEN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Configuration config = getBaseContext().getResources().getConfiguration();
                Locale locale = new Locale("en","GB");
                Locale.setDefault(locale);
                config.locale = locale;
                getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
                recreate();
            }
        });
        imgES.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Configuration config = getBaseContext().getResources().getConfiguration();
                Locale locale = new Locale("es","ES");
                Locale.setDefault(locale);
                config.locale = locale;
                getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
                recreate();
            }
        });
        mCodeScanner.setDecodeCallback(new DecodeCallback() {//recoge el texto escaneado del qr y lo muestra
            @Override
            public void onDecoded(@NonNull final Result result) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        editInvernadero.setText( result.getText().toString());
                    }
                });
            }
        });
        scannerView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mCodeScanner.startPreview();
            }
        });


        //Abre la actividad de inicio de sesion

        txtInicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent registerActivity = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(registerActivity);
                finish();
            }
        });

        btnRegistro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nombre = editNombreUsuario.getText().toString();
                String email = editEmail.getText().toString();
                String password = editPassword.getText().toString();
                String password2 = editPasswordConfirmar.getText().toString();
                String codigo_invernadero = editInvernadero.getText().toString();
                if(controlDeErorres( nombre,  email, password, password2,codigo_invernadero)){
                    AltaUsuarioDto user = new AltaUsuarioDto();
                    user.setCorreo(email);
                    user.setNombre(nombre);
                    user.setPwd(password);
                    user.setPwd2(password2);
                    user.setCodigo_invernadero(codigo_invernadero);
                    obtenerUsuarioRest(user);
                }
            }
        });

    }

    /**
     * Método que comprueba que el emailsea valido y los campos no esten vacíos o que haya más de 6
     * caracteres
     * @param nombre nombre de usuario
     * @param email email del usuario
     * @param pwd contraseña del usuario
     * @param pwd2 confirmación de contraseña del usuario
     * @return false si hay algún error true en caso de que no haya error
     */
    public boolean controlDeErorres(String nombre, String email,String pwd,String pwd2,String codigo_invernadero){
        Pattern pattern = Patterns.EMAIL_ADDRESS;
        String mensaje="";
        if (nombre.equals("") || email.equals("") || pwd.equals("") || pwd2.equals("") || codigo_invernadero.equals("")){
            mensaje = "Campos vacios";
            respuestaError(mensaje);
            Log.d("Login", mensaje);
            return false;
        }
        if (nombre.length() < 4 || email.length() < 4|| pwd.length() < 4 || pwd2.length() < 4 || codigo_invernadero.length() < 4){
            mensaje = "Menos que 4 caracteres";
            Log.d("Login", mensaje);
            respuestaError(mensaje);
            return false;
        }
        if(!pattern.matcher(email).matches()){
            mensaje="Email no válido";
            Log.d("Login", mensaje);
            respuestaError(mensaje);
            return false;
        }
        if(!pwd.equals(pwd2)){
            mensaje="Las contraseñas no coinciden";
            Log.d("Login", mensaje);
            respuestaError(mensaje);
            return false;
        }
        return true;
    }

    /**
     * Método para mostrar un mensaje de error durante 5 segundos
     */
    public void respuestaError(String mensaje){
        new CountDownTimer(5000, 1000) {

            public void onTick(long millisUntilFinished) {
                registroError.setText(mensaje);

            }

            @Override
            public void onFinish() {
                registroError.setText("");
            }

        }.start();
    }

    /**
     * Dar de alta el ususario
     * @param u usuario que se quiere dar de alta
     */
    public void obtenerUsuarioRest(AltaUsuarioDto u){
        mostrarEspera();

        GoRestUsuarioApiService goRestUsuarioApiService =
                GestorUsuario.getInstance().getGoRestUserApiService();

        Call<JwtResponse> call = goRestUsuarioApiService.altaUsuairo(u);
        call.enqueue(new Callback<JwtResponse>() {

            @Override
            public void onResponse(Call<JwtResponse> call, Response<JwtResponse> response) {
                if (response.isSuccessful()) {
                    cancelarEspera();
                    tokenSingletone = tokenSingletone.getInstance();

                    JwtResponse usuario = response.body();
                    System.out.println(usuario);
                    tokenSingletone.setToken(usuario.getToken());
                    tokenSingletone.setNombre(usuario.getNombre());
                    tokenSingletone.setId(Integer.parseInt(usuario.getId_usario()));

                    Intent mainActivity = new Intent(RegisterActivity.this, MainActivity.class);
                    startActivity(mainActivity);
                    finish();
                } else {
                    Log.d("Login", response.code() + " " + response.message());
                    return;
                }

                cancelarEspera();
            }

            @Override
            public void onFailure(Call<JwtResponse> call, Throwable t) {
                Log.d("Error", t.toString());
                cancelarEspera();
                respuestaError("algo ha fallado");
                respuestaError("usuario o correo duplicado");
            }
        });
    }
    /**
     * Método que muestra un dialogo personalizado
     */
    public void mostrarEspera() {
        dialogoGif = new DialogoGif();
        dialogoGif.setContext(RegisterActivity.this);
        dialogoGif.mostrarDialogo();
    }

    /**
     * Método que termina con el ProgressDialog
     */
    public void cancelarEspera(){
        dialogoGif.ocultarDialogo();
    }

    @Override
    public void onResume() {
        super.onResume();
        mCodeScanner.startPreview();
    }

    @Override
    public void onPause() {
        mCodeScanner.releaseResources();
        super.onPause();
    }
}