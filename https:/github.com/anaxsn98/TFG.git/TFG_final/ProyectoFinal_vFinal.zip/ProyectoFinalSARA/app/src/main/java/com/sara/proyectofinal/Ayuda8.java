package com.sara.proyectofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Ayuda8 extends AppCompatActivity {
    private Button btnAyuda8;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ayuda8);
        btnAyuda8 = findViewById(R.id.btnAyuda8);
        btnAyuda8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent( getApplicationContext(),MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}