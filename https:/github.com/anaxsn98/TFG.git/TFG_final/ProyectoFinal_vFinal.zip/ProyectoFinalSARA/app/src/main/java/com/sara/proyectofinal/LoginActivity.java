package com.sara.proyectofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.sara.proyectofinal.modelo.entidad.JwtRequest;
import com.sara.proyectofinal.modelo.entidad.JwtResponse;
import com.sara.proyectofinal.modelo.negocio.GestorPlanta;
import com.sara.proyectofinal.modelo.negocio.GestorTiposplanta;
import com.sara.proyectofinal.modelo.negocio.GestorUsuario;
import com.sara.proyectofinal.modelo.servicio.GoRestUsuarioApiService;
import com.sara.proyectofinal.singleton.TokenSingletone;

import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {
    private String userid;
    private Button botonEntrar;
    private EditText editEmail, editPassword;
    private TextView tvOlvidasteContrasena, txtRegistrate,loginError,recuerda;
    private ImageView imgEN,imgES;
    private DialogoGif dialogoGif;
    private TokenSingletone tokenSingletone;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //Inicializar gestores
        GestorPlanta.getInstance().inicializar();
        GestorUsuario.getInstance().inicializar();
        GestorTiposplanta.getInstance().inicializar();

        recuerda = findViewById(R.id.recuerda);
        txtRegistrate = findViewById(R.id.txtRegistrate);
        botonEntrar = findViewById(R.id.buttonEntrar);
        editEmail = findViewById(R.id.email);
        editPassword = findViewById(R.id.password);
        tvOlvidasteContrasena = findViewById(R.id.recuerda);
        loginError = findViewById(R.id.LoginError);
        imgEN = findViewById(R.id.imgEN);
        imgES = findViewById(R.id.imgES);

        GestorUsuario.getInstance().inicializar();

        recuerda.setOnClickListener(new View.OnClickListener() {//cambiar de activity a recuperar contraseña
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, ForgetPasswordActivity.class);
                startActivity(intent);
                finish();
            }
        });

        imgEN.setOnClickListener(new View.OnClickListener() {//cambiar de idioma
            @Override
            public void onClick(View view) {
                Configuration config = getBaseContext().getResources().getConfiguration();
                Locale locale = new Locale("en","GB");
                Locale.setDefault(locale);
                config.locale = locale;
                getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
                recreate();
            }
        });
        imgES.setOnClickListener(new View.OnClickListener() {//cambiar de idioma
            @Override
            public void onClick(View view) {
                Configuration config = getBaseContext().getResources().getConfiguration();
                Locale locale = new Locale("es","ES");
                Locale.setDefault(locale);
                config.locale = locale;
                getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
                recreate();
            }
        });


        /**
         * Comprueba si los datos introducidos son validos para procesar el login, en caso contrario,
         * avisa al usuario.
         */
        botonEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String textEmail = editEmail.getText().toString();
                String textPassword = editPassword.getText().toString();

                 if(controlDeErorres(textEmail,textPassword)){
                    obtenerUsuarioRest(textEmail,textPassword);
                }


            }
        });

        /**
         * Abre la actividad del registro*/
        txtRegistrate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent2);
                finish();
            }
        });
    }

    /**
     * Método que comprueba que el email y la contraseña no esten vacíos o que haya más de 6
     * caracteres
     * @param usu texto con el usuario introducido
     * @param contra texto con la contraseña introducida
     * @return false si hay algún error true en caso de que no haya error
     */
    public boolean controlDeErorres(String usu, String contra){
        if (usu.equals("") || contra.equals("")){
            respuestaError();
            Log.d("Login", "Campos vacios");
            return false;
        }else if (usu.length() < 4 || contra.length() < 4){
            Log.d("Login", "Menos que 4 caracteres");
            respuestaError();
            return false;
        }

        return true;
    }

    /**
     * Método para mostrar un mensaje de error durante 5 segundos
     */
    public void respuestaError(){
        new CountDownTimer(5000, 1000) {

            public void onTick(long millisUntilFinished) {
                loginError.setText("Email o contraseña no válido");

            }

            @Override
            public void onFinish() {
                loginError.setText("");
            }

        }.start();
    }
    /**
     *  Método rest que accede a la base de datos comprueba que el usuairo existe y si existe devuelve
     *  un token de autenticación
     * @param email email del usuario
     */
    public void obtenerUsuarioRest(String email,String pwd){
        mostrarEspera();
        JwtRequest user = new JwtRequest();
        user.setUsername(email);
        user.setPassword(pwd);

        GoRestUsuarioApiService goRestUsuarioApiService =
                GestorUsuario.getInstance().getGoRestUserApiService();

        Call<JwtResponse> call = goRestUsuarioApiService.login(user);

        call.enqueue(new Callback<JwtResponse>() {
            @Override
            public void onResponse(Call<JwtResponse> call, Response<JwtResponse> response) {
                if (response.isSuccessful()) {
                    Log.d("Login", "busqueda hecha");
                    //Gracias a Gson, me convierte los json a objetos UsuarioActivity
                    cancelarEspera();
                    tokenSingletone = tokenSingletone.getInstance();
                    JwtResponse usuario = response.body();
                    tokenSingletone.setToken(usuario.getToken());
                    tokenSingletone.setNombre(usuario.getNombre());
                    tokenSingletone.setId(Integer.parseInt(usuario.getId_usario()));

                    Intent mainActivity = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(mainActivity);
                    finish();

                } else {
                    Log.d("Login", response.code() + " " + response.message());
                    respuestaError();
                }

                cancelarEspera();
            }

            @Override
            public void onFailure(Call<JwtResponse> call, Throwable t) {
                Log.d("Error", t.toString());
                cancelarEspera();
                respuestaError();
            }
        });
    }

    /**
     * Método que muestra un dialogo personalizado
     */
    public void mostrarEspera() {
        dialogoGif = new DialogoGif();
        dialogoGif.setContext(LoginActivity.this);
        dialogoGif.mostrarDialogo();
    }

    /**
     * Método que termina con el dialogo
     */
    public void cancelarEspera(){
        dialogoGif.ocultarDialogo();
    }
}

