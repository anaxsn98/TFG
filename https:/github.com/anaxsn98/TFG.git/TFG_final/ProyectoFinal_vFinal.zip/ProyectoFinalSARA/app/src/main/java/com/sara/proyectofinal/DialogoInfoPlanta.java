package com.sara.proyectofinal;

import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentTransaction;

import com.bumptech.glide.Glide;

import java.util.Locale;


public class DialogoInfoPlanta extends DialogFragment {

    private TextView info_nombre,info_intervaloTiempo,info_intervaloLuz,info_intervaloViento,
            info_ml,info_minLuz,info_minViento,info_fini,info_ffin;
    private ImageView info_imgVegetable;

    public DialogoInfoPlanta() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        //Establecemos que no se pueda cancelar al pulsar fuera de la pantalla
        getDialog().setCanceledOnTouchOutside(false);
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    /**
     * Hacemos un getActivity.getLayoutInflater() para inflar un xml
     *  en el que hemos diseñado una vista y pasarselo al builder.setView()
     * @param savedInstanceState
     * @return dialogo
     */
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        View view=LayoutInflater.from(getActivity().getApplicationContext()).inflate(R.layout.info_planta,null);

        Configuration config = view.getContext().getResources().getConfiguration();
        Locale locale = getResources().getConfiguration().locale;
        Locale.setDefault(locale);
        config.locale = locale;
        view.getContext().getResources().updateConfiguration(config, view.getContext().getResources().getDisplayMetrics());

        builder.setView(view);

        Bundle bundle = getArguments();
        String[] intervalos = getResources().getStringArray(R.array.desplegableIntervalo);

        info_nombre = view.findViewById(R.id.info_nombre);
        info_imgVegetable = view.findViewById(R.id.info_imgVegetable);
        info_intervaloTiempo = view.findViewById(R.id.info_intervaloTiempo);
        info_intervaloLuz = view.findViewById(R.id.info_intervaloLuz);
        info_intervaloViento = view.findViewById(R.id.info_intervaloViento);
        info_ml = view.findViewById(R.id.info_ml);
        info_minLuz = view.findViewById(R.id.info_minLuz);
        info_minViento = view.findViewById(R.id.info_minViento);
        info_ffin = view.findViewById(R.id.info_fFin);
        info_fini = view.findViewById(R.id.info_fIni);

        String img = bundle.getString("img","");
        String nombre = bundle.getString("nombre","");
        String i = bundle.getString("riego","");
        String j = bundle.getString("luz","");
        String k = bundle.getString("ventilador","");
        String l = bundle.getString("fIni","");
        String m = bundle.getString("ffin","-");

        info_intervaloTiempo.setText(intervalos[Integer.parseInt(i)]);
        info_intervaloLuz.setText(intervalos[Integer.parseInt(j)]);
        info_intervaloViento.setText(intervalos[Integer.parseInt(k)]);
        info_minLuz.setText(bundle.getString("minLuz",""));
        info_minViento.setText(bundle.getString("minventilador",""));
        info_ml.setText(bundle.getString("ml",""));
        info_fini.setText(l);
        info_ffin.setText(m);
        info_nombre.setText(nombre);
        if(!img.equals(""))
            info_imgVegetable.setImageBitmap(stringToBitMap(img));

        builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                }
        });

        return builder.create();
    }

    /**
     * Método que decodifica  una imagen en base 64 a bitmap
     * @param encodedString
     * @return bitmap (from given string)
     */
    public Bitmap stringToBitMap(String encodedString){
        try {
            byte [] encodeByte= Base64.decode(encodedString,Base64.DEFAULT);
            Bitmap bitmap= BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.length);
            return bitmap;
        } catch(Exception e) {
            e.getMessage();
            return null;
        }
    }

}