package com.sara.proyectofinal.modelo.entidad;

import java.io.Serializable;
import java.util.List;


public class Tiposplanta implements Serializable {
	private int id_tipoplanta;
	private String nombre;
	private String img_url;

	public Tiposplanta(int id_tipoplanta, String nombre, String img_url) {
		super();
		this.id_tipoplanta = id_tipoplanta;
		this.nombre = nombre;
		this.img_url = img_url;
	}

	public Tiposplanta() {
		super();
	}

	public int getId_tipoplanta() {
		return id_tipoplanta;
	}

	public void setId_tipoplanta(int id_tipoplanta) {
		this.id_tipoplanta = id_tipoplanta;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getImg_url() {
		return img_url;
	}

	public void setImg_url(String img_url) {
		this.img_url = img_url;
	}

	@Override
	public String toString() {
		return "Tiposplanta{" +
				"id_tipoplanta=" + id_tipoplanta +
				", nombre='" + nombre + '\'' +
				", img_url='" + img_url + '\'' +
				'}';
	}
}
