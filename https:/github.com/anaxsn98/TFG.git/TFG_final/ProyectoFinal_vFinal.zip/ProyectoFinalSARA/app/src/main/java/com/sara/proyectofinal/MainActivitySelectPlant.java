package com.sara.proyectofinal;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.sara.proyectofinal.modelo.entidad.Tiposplanta;
import com.sara.proyectofinal.singleton.TiposplantaSingletone;

import java.util.Locale;

public class MainActivitySelectPlant extends AppCompatActivity {

    public LinearLayout personalizedPlant, defaultPlant;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_select_plant);

        personalizedPlant =findViewById(R.id.layoutPlantPersonalized);
        defaultPlant =findViewById(R.id.layouPlantDefault);

        defaultPlant.setOnClickListener(new View.OnClickListener() {//opcion planta predeterminada
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivitySelectPlant.this, SelectorPlantaPredeterminadaActivity.class);
                startActivity(intent);
                finish();
            }
        });

        personalizedPlant.setOnClickListener(new View.OnClickListener() {//opción personalizar planta
            @Override
            public void onClick(View view) {
                Tiposplanta tiposplanta = TiposplantaSingletone.getInstance().getListaTiposplanta().get(3);
                Intent intent = new Intent(MainActivitySelectPlant.this, DetallePlantaPredeterminadaActivity.class);
                intent.putExtra("Tiposplanta", tiposplanta);
                startActivity(intent);
                finish();
            }
        });


    }

    /**
     * Este método es llamado luego de onCreate().
     *
     * Comprueba el idioma seleccionado en la aplicación y lo aplica en la vista correspondiente
     */
    @Override
    protected void onStart() {
        super.onStart();
        Log.d("MainActivity", "onStart()");
        Configuration config = getBaseContext().getResources().getConfiguration();
        Locale locale = getResources().getConfiguration().locale;
        Locale.setDefault(locale);
        config.locale = locale;
        getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
    }
}