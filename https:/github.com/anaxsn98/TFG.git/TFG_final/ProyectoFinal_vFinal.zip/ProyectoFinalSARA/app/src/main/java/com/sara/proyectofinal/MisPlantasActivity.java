package com.sara.proyectofinal;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationBarView;
import com.sara.proyectofinal.adaptador.AdaptadorPlantas;
import com.sara.proyectofinal.modelo.entidad.Planta;
import com.sara.proyectofinal.modelo.negocio.GestorPlanta;
import com.sara.proyectofinal.modelo.servicio.GoRestPlantaApiService;
import com.sara.proyectofinal.singleton.TokenSingletone;

import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import androidx.appcompat.app.AlertDialog;

import android.content.DialogInterface;
import android.widget.ImageView;
import android.widget.TextView;


public class MisPlantasActivity extends AppCompatActivity {
    private Toolbar toolbar;
    private BottomNavigationView bottomNavigationView;
    public RecyclerView recyclerView;
    public AdaptadorPlantas adaptadorplanta;
    public FloatingActionButton addButton;
    private DialogoGif dialogoGif;
    private TokenSingletone tokenSingletone;
    private List<Planta> listaPlantas;
    private TextView TextoBienbenida;
    private ImageView animation_view_add_plant;
    private  FragmentManager fm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_plant);

        fm = getSupportFragmentManager();

        addButton = findViewById(R.id.btnAddPlant);
        TextoBienbenida = findViewById(R.id.TextoBienbenida);
        bottomNavigationView = findViewById(R.id.bottomNavigationBar);
        animation_view_add_plant = findViewById(R.id.animation_view_add_plant);
        tokenSingletone = TokenSingletone.getInstance();
        TextoBienbenida.setText("¡Hola "+tokenSingletone.getNombre()+"!");

        listaPlantasUsuario();





        //controlador = Controlador.getInstance();
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("");
        //controlador.verCarrito();
        //Bundle que en caso de venir de login no estará vacío, por lo que guardará el valor del id en userId.
        setSupportActionBar(toolbar);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(comoprobarExistenciaPlantaActual()){
                    //dialogo
                    System.out.println("Abrir dialogo");
                    dialogoPlantaNueva();
                }else{
                    System.out.println("No abrir dialogo");
                    Intent mainActivity = new Intent(MisPlantasActivity.this, MainActivitySelectPlant.class);
                    startActivity(mainActivity);
                    finish();
                }

            }
        });

        bottomNavigationView.setSelectedItemId(R.id.misPlantas);
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Intent intent;
                int id = item.getItemId();
                switch(id){
                    case R.id.planta:
                        intent = new Intent( getApplicationContext(),MainActivity.class);
                        startActivity(intent);
                        finish();
                        return true;
                    case R.id.misPlantas:
                        intent = new Intent( getApplicationContext(),MisPlantasActivity.class);
                        startActivity(intent);
                        finish();
                        return true;
                    case R.id.calendario:
                        intent = new Intent( getApplicationContext(),Calendario.class);
                        startActivity(intent);
                        finish();
                        return true;
                }
                return true;
            }
        });
    }
    /**
     * Recoge el menu que hemos creado en un xml y lo infla en la vista
     * Devuelve verdadero en caasao de que pueda ejecytar el proceso
     *
     * @param menu
     * @return true
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_bar, menu);
        //menu.findItem(R.id.UsuarioActivity).setVisible(true);
        return true;
    }

    /**
     * Recoge el id de los items que hemos creado en el menu
     * Si el id corresponde al de carrito se hará el proceso correspondiente
     *
     * @param item recoge los items de las opciones del menu.
     * @return boolean
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.ayuda) {//abrir un activity
            Intent intent = new Intent( this,Ayuda1.class);
            startActivity(intent);
            finish();
        }
        if (id == R.id.menu_castellano) { //cambiar de idioma la aplicación
            Configuration config = getBaseContext().getResources().getConfiguration();
            Locale locale = new Locale("es","ES");
            Locale.setDefault(locale);
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
            recreate();
        }
        if (id == R.id.menu_ingles) {//cambiar de idioma de la aplicación
            Configuration config = getBaseContext().getResources().getConfiguration();
            Locale locale = new Locale("en","GB");
            Locale.setDefault(locale);
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
            recreate();
        }
        if (id == R.id.menu_usuario) { //abrir un activity
            Intent intent = new Intent( this, UsuarioActivity.class);
            startActivity(intent);
            finish();
        }
        if (id == R.id.logout) {//abrir un activity
            Intent intent = new Intent( this, LoginActivity.class);
            startActivity(intent);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    public void cargarListaPlantas(int id){

    }

    /**
     *  Método rest que accede a la base de dator para obtener la lista de plantas del usuario e
     *  inicializa el adaptador de plantas con la lista
     */
    public void listaPlantasUsuario(){
        mostrarEspera();
        tokenSingletone = TokenSingletone.getInstance();
        System.out.println(tokenSingletone);
        GoRestPlantaApiService goRestPlantaApiService =
                GestorPlanta.getInstance().getGoRestPlantaApiService();

        Call<List<Planta>> call = goRestPlantaApiService.buscarTodasLasPlantasDelUsuario(tokenSingletone.getToken(), tokenSingletone.getId());

        call.enqueue(new Callback<List<Planta>>() {
            @Override
            public void onResponse(Call<List<Planta>> call, Response<List<Planta>> response) {
                if (response.isSuccessful()) {
                    Log.d("Lista Planta", "busqueda hecha");
                    listaPlantas = response.body();
                    if(listaPlantas.size() < 1){
                        animation_view_add_plant.setVisibility(View.VISIBLE);
                    }else{
                        animation_view_add_plant.setVisibility(View.GONE);
                    }
                    //le pasamos la lista al adaptador
                    adaptadorplanta = new AdaptadorPlantas(listaPlantas,fm);
                    recyclerView = findViewById(R.id.rViewPlantas);
                    //Mejora el rendimiento, si el contenido no afecta al tamaño del reciclerView
                    recyclerView.setHasFixedSize(true);
                    //El recicler va a utilizar un linear layout
                    recyclerView.setLayoutManager(
                            new GridLayoutManager(
                                    getApplicationContext(),
                                    2));

                    //Le pasamos el adaptador
                    recyclerView.setAdapter(adaptadorplanta);
                    cancelarEspera();

                } else {
                    Log.d("Lista Planta", response.code() + " " + response.message());

                }

                cancelarEspera();
            }

            @Override
            public void onFailure(Call<List<Planta>> call, Throwable t) {
                Log.d("Lista Planta", t.toString());
                cancelarEspera();
            }
        });
    }
    /**
     *  Método rest que accede a la base dar de baja la planta actual
     */
    public void terminarPlantaActual(){
        mostrarEspera();
        tokenSingletone = TokenSingletone.getInstance();
        System.out.println(tokenSingletone);
        GoRestPlantaApiService goRestUsuarioApiService =
                GestorPlanta.getInstance().getGoRestPlantaApiService();

        Call<Planta> call = goRestUsuarioApiService.terminarPlantaActual(tokenSingletone.getToken(), tokenSingletone.getId());

        call.enqueue(new Callback<Planta>() {
            @Override
            public void onResponse(Call<Planta> call, Response<Planta> response) {
                if (response.isSuccessful()) {
                    Log.d("Terminar Planta Actual", "busqueda hecha");

                    if(listaPlantas.size() < 1){
                        animation_view_add_plant.setVisibility(View.VISIBLE);
                    }else{
                        animation_view_add_plant.setVisibility(View.GONE);
                    }
                    cancelarEspera();

                } else {
                    Log.d("Terminar Planta Actual", response.code() + " " + response.message());

                }

                cancelarEspera();
            }

            @Override
            public void onFailure(Call<Planta> call, Throwable t) {
                Log.d("Terminar Planta Actual", t.toString());
                cancelarEspera();
            }
        });
    }

    /**
     *  Método que comprueba si el usuario tiene una planta actual
     * @return true si el usuario tiene una planta actual, false en caso contrario
     */
    public boolean comoprobarExistenciaPlantaActual(){
        for (Planta p: this.listaPlantas
             ) {
            if(p.getFechaFin() == null || p.getFechaFin() == "")
                return true;
        }
        return false;
    }

    /**
     *  Método que abre un dialogo para preguntar al usuario si quiere dar de baja
     *  la planta actual y crear una nueva
    */
    public void dialogoPlantaNueva(){

        AlertDialog.Builder builder = new AlertDialog.Builder(MisPlantasActivity.this);
        builder.setMessage("Tu invernadero ya tiene una planta ¿Deseas dar de baja la planta actual y" +
                " crear una nueva planta?");

        builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {//cierra la actividad
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //dar de baja planta actual
                terminarPlantaActual();
                Intent mainActivity = new Intent(MisPlantasActivity.this, MainActivitySelectPlant.class);
                startActivity(mainActivity);
                finish();
            }
        });

        builder.setNegativeButton("Cancelar", null);

        AlertDialog dialog = builder.create();

        dialog.setCanceledOnTouchOutside(false);
        dialog.show();



    }

    /**
     * Método que muestra un dialogo personalizado
     */
    public void mostrarEspera() {
        dialogoGif = new DialogoGif();
        dialogoGif.setContext(MisPlantasActivity.this);
        dialogoGif.mostrarDialogo();
    }

    /**
     * Método que termina con el dialogo
     */
    public void cancelarEspera(){
        dialogoGif.ocultarDialogo();
    }
}