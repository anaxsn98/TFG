package com.sara.proyectofinal;

import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.sara.proyectofinal.modelo.entidad.Tiposplanta;
import com.sara.proyectofinal.singleton.TiposplantaSingletone;

import java.util.List;
import java.util.Locale;

public class SelectorPlantaPredeterminadaActivity extends AppCompatActivity {
    private TextView tiposplanta1,tiposplanta2,tiposplanta3;
    private ImageView img_tiposplanta1,img_tiposplanta2,img_tiposplanta3;
    private LinearLayout layout_tiposplanta1,layout_tiposplanta2,layout_tiposplanta3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selector_planta_predeterminada);

        List<Tiposplanta> listaTiposplanta;
        tiposplanta1 = findViewById(R.id.tiposplanta1);
        tiposplanta2 = findViewById(R.id.tiposplanta2);
        tiposplanta3 = findViewById(R.id.tiposplanta3);
        img_tiposplanta1 = findViewById(R.id.img_tiposplanta1);
        img_tiposplanta2= findViewById(R.id.img_tiposplanta2);
        img_tiposplanta3= findViewById(R.id.img_tiposplanta3);
        layout_tiposplanta1 = findViewById(R.id.layout_tiposplanta1);
        layout_tiposplanta2 = findViewById(R.id.layout_tiposplanta2);
        layout_tiposplanta3 = findViewById(R.id.layout_tiposplanta3);

        listaTiposplanta = TiposplantaSingletone.getInstance().getListaTiposplanta();
        for (Tiposplanta t: listaTiposplanta
        ) {
            System.out.println(t);
        }
        if(listaTiposplanta.get(0).getImg_url() != null && !listaTiposplanta.get(0).getImg_url().equals(""))
            img_tiposplanta1.setImageBitmap(stringToBitMap(listaTiposplanta.get(0).getImg_url()));
        if(listaTiposplanta.get(1).getImg_url() != null && !listaTiposplanta.get(1).getImg_url().equals(""))
            img_tiposplanta2.setImageBitmap(stringToBitMap(listaTiposplanta.get(1).getImg_url()));
        if(listaTiposplanta.get(2).getImg_url() != null && !listaTiposplanta.get(2).getImg_url().equals(""))
            img_tiposplanta3.setImageBitmap(stringToBitMap(listaTiposplanta.get(2).getImg_url()));

        tiposplanta1.setText(listaTiposplanta.get(0).getNombre());
        tiposplanta2.setText(listaTiposplanta.get(1).getNombre());
        tiposplanta3.setText(listaTiposplanta.get(2).getNombre());

        layout_tiposplanta1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Tiposplanta tiposplanta = listaTiposplanta.get(0);
                Intent intent = new Intent(SelectorPlantaPredeterminadaActivity.this, DetallePlantaPredeterminadaActivity.class);
                intent.putExtra("Tiposplanta", tiposplanta);
                startActivity(intent);
                finish();
            }
        });

        layout_tiposplanta2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Tiposplanta tiposplanta = listaTiposplanta.get(1);
                Intent intent = new Intent(SelectorPlantaPredeterminadaActivity.this, DetallePlantaPredeterminadaActivity.class);
                intent.putExtra("Tiposplanta", tiposplanta);
                startActivity(intent);
                finish();
            }
        });
        layout_tiposplanta3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Tiposplanta tiposplanta = listaTiposplanta.get(2);
                Intent intent = new Intent(SelectorPlantaPredeterminadaActivity.this, DetallePlantaPredeterminadaActivity.class);
                intent.putExtra("Tiposplanta", tiposplanta);
                startActivity(intent);
                finish();
            }
        });
    }

    /**
     * Método que decodifica  una imagen en base 64 a bitmap
     * @param encodedString
     * @return bitmap (from given string)
     */
    public Bitmap stringToBitMap(String encodedString){
        try {
            byte [] encodeByte= Base64.decode(encodedString,Base64.DEFAULT);
            Bitmap bitmap= BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.length);
            return bitmap;
        } catch(Exception e) {
            e.getMessage();
            return null;
        }
    }

    /**
     * Este método es llamado luego de onCreate().
     *
     * Comprueba el idioma seleccionado en la aplicación y lo aplica en la vista correspondiente
     */
    @Override
    protected void onStart() {
        super.onStart();
        Log.d("MainActivity", "onStart()");
        Configuration config = getBaseContext().getResources().getConfiguration();
        Locale locale = getResources().getConfiguration().locale;
        Locale.setDefault(locale);
        config.locale = locale;
        getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        // recreate();
    }
}