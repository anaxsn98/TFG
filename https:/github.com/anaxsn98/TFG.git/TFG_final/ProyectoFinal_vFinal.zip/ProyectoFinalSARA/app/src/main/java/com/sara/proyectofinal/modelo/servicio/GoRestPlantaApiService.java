package com.sara.proyectofinal.modelo.servicio;

import com.sara.proyectofinal.modelo.entidad.Evento;
import com.sara.proyectofinal.modelo.entidad.Planta;
import com.sara.proyectofinal.modelo.entidad.Usuario;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface GoRestPlantaApiService {
    //Para poder hacer uso del servicio hay que logarse en la página y generar
    //un token de autenticación, luego hay que incluirlo en la cabecera, dentro
    //del parametros Authorization

    /**
     * Servicio que hace una búsqueda de todas las plantas que ha tenido y tiene el usuario
     * @param token token de autrorización
     * @param id id de usuario
     * @return Devuelve una lista de planta y el codigo de respuesta 200 ok o un 404
     * 	       not found si el usuario no tiene ninguna planta
     */
    @GET("usuarios/{id}/plantas/all")
    Call<List<Planta>> buscarTodasLasPlantasDelUsuario(@Header("Authorization") String token,
                                          @Path("id") int id);

    /**
     * Servicio que hace una búsqueda de la planta que está actualmente en el invernadero del
     * usuario
     * @param token token de autrorización
     * @param id id de usuario
     * @return Devuelve la planta actual y el codigo de respuesta 200 ok o un 404
     * 	       not found si el usuario no tiene ninguna planta actual
     */
    @GET("usuarios/{id}/plantas")
    Call<Planta> buscarPlantaActual(@Header("Authorization") String token,
                                                       @Path("id") int id);

    /**
     * Servicio que devuelve una lista de eventos de la planta actual. En caso de que el usuario
     * no tenga una planta actual devolverá 404 not found
     *
     * @param token token de autrorización
     * @param id id de usuario
     * @return Una lista de eventos y el codigo de respuesta 200 ok o un 404 not
     * 	 *         found si el usuario no tiene ninguna planta actual
     */
    @GET("usuarios/{id}/plantas/eventos")
    Call<List<Evento>> getEventos(@Header("Authorization") String token,
                                  @Path("id") int id);

    /**
     * Servicio que devuelve una lista de porcentajes de luz, riego y ventilación respectivamente
     * en caso de que el usuario tenga una planta actual
     * @param token token de autrorización
     * @param id id de usuario
     * @return Una lista de porcentajes y el codigo de respuesta 200 ok o un 404 not
     * 	 *         found si el usuario no tiene ninguna planta actual
     */
    @GET("usuarios/{id}/plantas/progress")
    Call<List<Integer>> getProgressBar(@Header("Authorization") String token,
                                  @Path("id") int id);

    /**
     * Servicio que da de alta una planta en la base de datos
     * @param token token de autrorización
     * @param id id de usuario
     * @param planta planta que se quiere dar de alta
     * @return el codigo de respuesta 201 created
     */
    @POST("usuarios/{id}/plantas")
    Call<Planta> altaPlanta(@Header("Authorization") String token,
                              @Path("id") int id, @Body Planta planta);

    /**
     * Servicio que modifica los datos de la planta
     * @param token token de autrorización
     * @param id id de usuario
     * @param planta planta con datos modificados
     * @return el codigo de respuesta 200 "OK"
     */
    @PUT("usuarios/{id}/plantas")
    Call<Planta> modificarPlanta(@Header("Authorization") String token,
                                      @Path("id") int id, @Body Planta planta);

    /**
     * Servicio que comprueba si el usuairo tiene una planta actual y en caso de tenerla la da de
     * baja del invernadero es decir pone su fecha fin con la fecha actual
     * @param token token de autrorización
     * @param id id de usuario
     * @return Devuelve la planta modificada y el codigo de respuesta 200 ok o un
     *         404 not found si el usuario no tiene ninguna planta actual
     */
    @PUT("usuarios/{id}/plantas/finalizar")
    Call<Planta> terminarPlantaActual(@Header("Authorization") String token,
                            @Path("id") int id);

    /**
     * Servicio que elimina una planta de la base de datos
     * @param token token de autrorización
     * @param id id de usuario
     * @return Devuelve el codigo de respuesta 200 ok si se ha eliminado o un
     * 	       404 not found si no se ha encontrado una planta con ese id
     */
    @DELETE("plantas/{id}")
    Call<Planta> borrarPlanta(@Header("Authorization") String token,
                              @Path("id") int id);
}
