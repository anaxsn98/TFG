package com.sara.proyectofinal;

import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.sara.proyectofinal.modelo.entidad.Planta;
import com.sara.proyectofinal.modelo.entidad.Tiposplanta;
import com.sara.proyectofinal.modelo.negocio.GestorPlanta;
import com.sara.proyectofinal.modelo.negocio.GestorTiposplanta;
import com.sara.proyectofinal.modelo.servicio.GoRestPlantaApiService;
import com.sara.proyectofinal.modelo.servicio.GoRestTiposplantaApiService;
import com.sara.proyectofinal.singleton.PlantaSingletone;
import com.sara.proyectofinal.singleton.TiposplantaSingletone;
import com.sara.proyectofinal.singleton.TokenSingletone;

import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private TiposplantaSingletone tiposplantaSingletone;
    private PlantaSingletone plantaSingletone;
    private DialogoGif dialogoGif;
    private TokenSingletone tokenSingletone;

    private FragmentTransaction ft;
    private Fragment_control fragment_control;
    private Fragment_estado fragment_estado;

    private TextView nombrePlanta,main_bajaPlanta;
    private Toolbar toolbar;
    private BottomNavigationView bottomNavigationView;
    private ImageView imgVegetable;

    private Button btn_estado,btn_control;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getListaTiposPlanta();

        //controlador = Controlador.getInstance();
        toolbar = findViewById(R.id.toolbar);
        tokenSingletone = TokenSingletone.getInstance();
        bottomNavigationView = findViewById(R.id.bottomNavigationBar);
        nombrePlanta = findViewById(R.id.main_nombre_planta);
        main_bajaPlanta = findViewById(R.id.main_bajaPlanta);
        //Imagen
        imgVegetable = findViewById(R.id.imgVegetable);
        btn_estado = findViewById(R.id.btn_estado);
        btn_control = findViewById(R.id.btn_control);

        toolbar.setTitle("");
        setSupportActionBar(toolbar);


        fragment_control = new Fragment_control();
        fragment_estado = new Fragment_estado();
        getSupportFragmentManager().beginTransaction().add(R.id.contenedorFragmentos,fragment_estado).commit();



        btn_control.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                ft = getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.contenedorFragmentos,fragment_control);
                ft.commit();
            }
        });
        btn_estado.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                ft = getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.contenedorFragmentos,fragment_estado);
                ft.commit();
            }
        });

        main_bajaPlanta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                terminarPlantaActual();
            }
        });

        bottomNavigationView.setSelectedItemId(R.id.planta);
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Intent intent;
                int id = item.getItemId();
                switch(id){
                    case R.id.planta:
                        intent = new Intent( getApplicationContext(),MainActivity.class);
                        startActivity(intent);
                        finish();
                        return true;
                    case R.id.misPlantas:
                        intent = new Intent( getApplicationContext(),MisPlantasActivity.class);
                        startActivity(intent);
                        finish();
                        return true;
                    case R.id.calendario:
                        intent = new Intent( getApplicationContext(),Calendario.class);
                        startActivity(intent);
                        finish();
                        return true;
                }
                return true;
            }
        });
    }

    /**
     * Recoge el menu que hemos creado en un xml y lo infla en la vista
     * Devuelve verdadero en caasao de que pueda ejecytar el proceso
     *
     * @param menu
     * @return true
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_bar, menu);
        return true;
    }

    /**
     * Recoge el id de los items que hemos creado en el menu
     * @param item recoge los items de las opciones del menu.
     * @return item ,Devuelve el id del item que se haya seleccionado.
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.ayuda) {
            Intent intent = new Intent( this,Ayuda1.class);
            startActivity(intent);
            finish();
        }
        if (id == R.id.menu_castellano) {
            Configuration config = getBaseContext().getResources().getConfiguration();
            Locale locale = new Locale("es","ES");
            Locale.setDefault(locale);
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
            recreate();
        }
        if (id == R.id.menu_ingles) {
            Configuration config = getBaseContext().getResources().getConfiguration();
            Locale locale = new Locale("en","GB");
            Locale.setDefault(locale);
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
            recreate();
        }
        if (id == R.id.menu_usuario) {
            Intent intent = new Intent( this, UsuarioActivity.class);
            startActivity(intent);
            finish();
        }
        if (id == R.id.logout) {
            Intent intent = new Intent( this, LoginActivity.class);
            startActivity(intent);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }


    /**
     *  Método rest que accede a la base de dator para obtener el usuario a partir del email que se
     *  ha introducido en el edittex
     */
    public void terminarPlantaActual(){
        mostrarEspera();
        tokenSingletone = TokenSingletone.getInstance();
        System.out.println(tokenSingletone);
        GoRestPlantaApiService goRestUsuarioApiService =
                GestorPlanta.getInstance().getGoRestPlantaApiService();

        Call<Planta> call = goRestUsuarioApiService.terminarPlantaActual(tokenSingletone.getToken(), tokenSingletone.getId());

        call.enqueue(new Callback<Planta>() {
            //Este método se ejecutará cuando el servidor HTTP nos responda
            //satisfactoriamente
            @Override
            public void onResponse(Call<Planta> call, Response<Planta> response) {
                if (response.isSuccessful()) {
                    Log.d("Terminar Planta Actual", "busqueda hecha");
                    cancelarEspera();
                    Intent intent = new Intent(MainActivity.this, MainPlantaActualNoExiste.class);
                    startActivity(intent);
                    finish();

                } else {
                    Log.d("Terminar Planta Actual", response.code() + " " + response.message());

                }

                cancelarEspera();
            }

            @Override
            public void onFailure(Call<Planta> call, Throwable t) {
                Log.d("Terminar Planta Actual", t.toString());
                cancelarEspera();
            }
        });
    }
    /**
     *  Método rest que accede a la base de dator para buscar la planta actual del usuario
     */
    public void buscarPlantaActual(){
        mostrarEspera();
        tokenSingletone = TokenSingletone.getInstance();
        System.out.println(tokenSingletone);
        GoRestPlantaApiService goRestUsuarioApiService =
                GestorPlanta.getInstance().getGoRestPlantaApiService();

        Call<Planta> call = goRestUsuarioApiService.buscarPlantaActual(tokenSingletone.getToken(), tokenSingletone.getId());

        call.enqueue(new Callback<Planta>() {
            //Este método se ejecutará cuando el servidor HTTP nos responda
            //satisfactoriamente
            @Override
            public void onResponse(Call<Planta> call, Response<Planta> response) {
                if (response.isSuccessful()) {
                    Log.d("Buscar Planta Actual", "busqueda hecha");
                    plantaSingletone = PlantaSingletone.getInstance();
                    plantaSingletone.setPlanta(response.body());
                    cancelarEspera();
                    plantaSingletone = PlantaSingletone.getInstance();
                    nombrePlanta.setText(plantaSingletone.getPlanta().getNombre());
                    if(plantaSingletone.getPlanta().getImg() != null && !plantaSingletone.getPlanta().getImg().equals(""))
                        imgVegetable.setImageBitmap(stringToBitMap(plantaSingletone.getPlanta().getImg()));

                } else {
                    Log.d("Buscar Planta Actual", response.code() + " " + response.message());
                    //no encontrada
                    cancelarEspera();
                    Intent intent = new Intent(MainActivity.this, MainPlantaActualNoExiste.class);
                    startActivity(intent);
                    finish();
                }

                cancelarEspera();
            }

            @Override
            public void onFailure(Call<Planta> call, Throwable t) {
                Log.d("Buscar Planta Actual", t.toString());
                cancelarEspera();
                Intent intent = new Intent(MainActivity.this, MainPlantaActualNoExiste.class);
                startActivity(intent);
                finish();
            }
        });
    }

    /**
     *  Método rest que accede a la base de dator para obtener el usuario a partir del email que se
     *  ha introducido en el edittex
     */
    public void getListaTiposPlanta(){
        mostrarEspera();

        GoRestTiposplantaApiService goRestTiposplantaApiService =
                GestorTiposplanta.getInstance().getGoRestUserApiService();
        tokenSingletone = TokenSingletone.getInstance();
        System.out.println(tokenSingletone);
        Call<List<Tiposplanta>> call = goRestTiposplantaApiService.getAllTipoPlanta(tokenSingletone.getToken());

        call.enqueue(new Callback<List<Tiposplanta>>() {
            //Este método se ejecutará cuando el servidor HTTP nos responda
            //satisfactoriamente
            @Override
            public void onResponse(Call<List<Tiposplanta>> call, Response<List<Tiposplanta>> response) {
                if (response.isSuccessful()) {
                    Log.d("main tipospplanta", "busqueda hecha");

                    TiposplantaSingletone tiposplantaSingletone = TiposplantaSingletone.getInstance();
                    tiposplantaSingletone.setListaTiposplanta(response.body());
                    cancelarEspera();
                    buscarPlantaActual();

                } else {
                    Log.d("main tipospplanta", response.code() + " " + response.message());

                }

                cancelarEspera();
            }

            @Override
            public void onFailure(Call<List<Tiposplanta>> call, Throwable t) {
                Log.d("main tipospplanta", t.toString());
                cancelarEspera();
            }
        });
    }

    /**
     * Método que muestra un ProgressDialog
     */
    public void mostrarEspera() {
        dialogoGif = new DialogoGif();
        dialogoGif.setContext(MainActivity.this);
        dialogoGif.mostrarDialogo();
    }

    /**
     * Método que termina con el ProgressDialog
     */
    public void cancelarEspera(){
        dialogoGif.ocultarDialogo();
    }

    /**
     * @param encodedString
     * @return bitmap (from given string)
     */
    public Bitmap stringToBitMap(String encodedString){
        try {
            byte [] encodeByte= Base64.decode(encodedString,Base64.DEFAULT);
            Bitmap bitmap= BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.length);
            return bitmap;
        } catch(Exception e) {
            e.getMessage();
            return null;
        }
    }
}
