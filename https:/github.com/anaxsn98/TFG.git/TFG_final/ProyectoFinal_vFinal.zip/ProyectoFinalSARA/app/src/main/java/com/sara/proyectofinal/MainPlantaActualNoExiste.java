package com.sara.proyectofinal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.sara.proyectofinal.singleton.TokenSingletone;

import java.util.Locale;

public class MainPlantaActualNoExiste extends AppCompatActivity {
    private Toolbar toolbar;
    private BottomNavigationView bottomNavigationView;
    private TokenSingletone tokenSingletone;
    private TextView main_crearPlanta,main_nombre_usuario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_planta_actual_no_existe);
        toolbar = findViewById(R.id.toolbar2);

        tokenSingletone = TokenSingletone.getInstance();
        bottomNavigationView = findViewById(R.id.bottomNavigationBar);
        main_nombre_usuario = findViewById(R.id.main_nombre_usuario);
        main_crearPlanta = findViewById(R.id.main_crearPlanta);
        tokenSingletone = TokenSingletone.getInstance();

        main_nombre_usuario.setText("¡Hola "+ tokenSingletone.getNombre()+"!");

        toolbar.setTitle("");
        setSupportActionBar(toolbar);

        bottomNavigationView.setSelectedItemId(R.id.planta);
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Intent intent;
                int id = item.getItemId();
                switch(id){
                    case R.id.planta:
                        intent = new Intent( getApplicationContext(),MainActivity.class);
                        startActivity(intent);
                        finish();
                        return true;
                    case R.id.misPlantas:
                        intent = new Intent( getApplicationContext(),MisPlantasActivity.class);
                        startActivity(intent);
                        finish();
                        return true;
                    case R.id.calendario:
                        intent = new Intent( getApplicationContext(),Calendario.class);
                        startActivity(intent);
                        finish();
                        return true;
                }
                return true;
            }
        });
        main_crearPlanta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent( getApplicationContext(),MisPlantasActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
    /**
     * Recoge el menu que hemos creado en un xml y lo infla en la vista
     * Devuelve verdadero en caasao de que pueda ejecytar el proceso
     *
     * @param menu
     * @return true
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_bar, menu);
        return true;
    }

    /**
     * Recoge el id de los items que hemos creado en el menu
     * Si el id corresponde al de carrito se hará el proceso correspondiente
     *
     * @param item recoge los items de las opciones del menu.
     * @return boolean
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.ayuda) {
            Intent intent = new Intent( this,Ayuda1.class);
            startActivity(intent);
            finish();
        }
        if (id == R.id.menu_castellano) {
            Configuration config = getBaseContext().getResources().getConfiguration();
            Locale locale = new Locale("es","ES");
            Locale.setDefault(locale);
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
            recreate();
        }
        if (id == R.id.menu_ingles) {
            Configuration config = getBaseContext().getResources().getConfiguration();
            Locale locale = new Locale("en","GB");
            Locale.setDefault(locale);
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
            recreate();
        }
        if (id == R.id.menu_usuario) {
            Intent intent = new Intent( this, UsuarioActivity.class);
            startActivity(intent);
            finish();
        }
        if (id == R.id.logout) {
            Intent intent = new Intent( this, LoginActivity.class);
            startActivity(intent);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

}