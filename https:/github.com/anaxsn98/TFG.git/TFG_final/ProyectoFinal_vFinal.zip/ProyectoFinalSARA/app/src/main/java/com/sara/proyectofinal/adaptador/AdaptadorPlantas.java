package com.sara.proyectofinal.adaptador;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.sara.proyectofinal.DialogoGif;
import com.sara.proyectofinal.DialogoInfoPlanta;
import com.sara.proyectofinal.R;
import com.sara.proyectofinal.modelo.entidad.Planta;
import com.sara.proyectofinal.modelo.negocio.GestorPlanta;
import com.sara.proyectofinal.modelo.servicio.GoRestPlantaApiService;
import com.sara.proyectofinal.singleton.TokenSingletone;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AdaptadorPlantas extends RecyclerView.Adapter<AdaptadorPlantas.ViewHolder> {
    private Context contexto;
    private List<Planta> listaPlanta;
    private DialogoGif dialogoGif;
    private TokenSingletone tokenSingletone;
    private FragmentManager fm;

    /**
     * Constructor
     * @param listaPlanta lista de plantas
     * @param fm fragment manager para poder pasar información a otro fragment
     */
    public AdaptadorPlantas(List<Planta> listaPlanta,FragmentManager fm) {
        this.listaPlanta = listaPlanta;
        this.fm = fm;
    }

    /**
     * Método que permite btener referencias de los componentes visuales para cada elemento
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {
        private TextView nombre;
        private ImageView img, eliminar_planta,ver_planta;


        public ViewHolder(View itemView) {
            super(itemView);
            nombre = itemView.findViewById(R.id.nombre_planta);
            img = itemView.findViewById(R.id.img_planta);
            eliminar_planta = itemView.findViewById(R.id.eliminar_planta);
            ver_planta = itemView.findViewById(R.id.ver_planta);
        }
    }

    /**
     * Método que define la cantidad de elementos del RecyclerView
     * @return  numero de elementos que contiene el RecyclerView
     */
    @Override
    public int getItemCount() {
        return listaPlanta.size();
    }

    /**
     * Método para renderizar cada elemento
     * @param parent
     * @param viewType
     * @return
     */
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        contexto = parent.getContext();
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recicler_view_cuadro, parent, false);
        ViewHolder viewHolder = new ViewHolder(v);
        return viewHolder;
    }

    /**
     * Este método se usa asigna valores para cada elemento de la lista o acciones de los
     * elementos
     * @param holder
     * @param position posición en la lista
     */
    @Override
    public void onBindViewHolder( ViewHolder holder, int position) {
        Planta planta = listaPlanta.get(position);
        String url_foto = planta.getImg();
        holder.img.setImageBitmap(stringToBitMap(url_foto));
        //Glide.with(contexto).load(url_foto).into(holder.img);
        holder.nombre.setText(planta.getNombre());
        holder.ver_planta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogoInfoPlanta dialogoRecogerValor = new DialogoInfoPlanta();
                Bundle bundle = new Bundle();
                bundle.putString("img", planta.getImg());
                bundle.putString("nombre", planta.getNombre());
                bundle.putString("ml",Integer.toString(planta.getMl()));
                bundle.putString("riego",Integer.toString(planta.getIntervaloTiempoRiego()));
                bundle.putString("luz",Integer.toString(planta.getIntervaloTiempoLuz()));
                bundle.putString("ventilador",Integer.toString(planta.getIntervaloTiempoVentilador()));
                bundle.putString("minLuz",Integer.toString(planta.getMinLuz()));
                bundle.putString("minventilador",Integer.toString(planta.getMinVentilador()));
                bundle.putString("fIni",planta.getFechaIni());
                bundle.putString("ffin",planta.getFechaFin());
                dialogoRecogerValor.setArguments(bundle);
                dialogoRecogerValor.show(fm,"MisPlantasActivity");
            }
        });
        holder.eliminar_planta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dialogoEliminarPlanta(planta,holder);


            }
        });
    }

    /**
     *  Método que abre un dialogo para preguntar al usuario si quiere dar eliminar una planta
     *  y en caso que le de a eliminar se ejecutará el servicio
     * @param planta planta que se quiere eliminar
     * @param holder
     */
    public void dialogoEliminarPlanta(Planta planta,ViewHolder holder){

        AlertDialog.Builder builder = new AlertDialog.Builder(contexto);
        builder.setMessage("¿Está seguro que desea eliminar la planta? Al realizar esta acción se prederá " +
                "toda la información  sobre esa planta");

        //En este caso si que voy a poner un listener al boton, ya que
        //quiero cerrar la actividad
        builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                borrarPlanta(planta.getId());
                listaPlanta.remove(holder.getAdapterPosition());
                notifyDataSetChanged();
            }
        });

        //Es este caso tambien meto el boton en caso de que no quiera
        //hacer la accion
        builder.setNegativeButton("Cancelar", null);

        AlertDialog dialog = builder.create();
        //Establecemos que no cancele el dialogo si pulsa fuera del cuadro
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();



    }


    /**
     *  Método rest para eliminar una planta por id
     * @param id id de planta
     */
    public void borrarPlanta(int id){
        mostrarEspera();
        tokenSingletone = TokenSingletone.getInstance();

        GoRestPlantaApiService goRestUsuarioApiService =
                GestorPlanta.getInstance().getGoRestPlantaApiService();

        Call<Planta> call = goRestUsuarioApiService.borrarPlanta(tokenSingletone.getToken(), id);

        call.enqueue(new Callback<Planta>() {
            @Override
            public void onResponse(Call<Planta> call, Response<Planta> response) {
                if (response.isSuccessful()) {
                    Log.d("Eliminar Planta", "busqueda hecha");

                    cancelarEspera();

                } else {
                    Log.d("Eliminar Planta", response.code() + " " + response.message());

                }

                cancelarEspera();
            }

            @Override
            public void onFailure(Call<Planta> call, Throwable t) {
                Log.d("Eliminar Planta", t.toString());
                cancelarEspera();
            }
        });
    }

    /**
     * Método que muestra un diálogo personalizado
     */
    public void mostrarEspera() {
        dialogoGif = new DialogoGif();
        dialogoGif.setContext(contexto);
        dialogoGif.mostrarDialogo();
    }

    /**
     * Método que termina con el diálogo
     */
    public void cancelarEspera(){
        dialogoGif.ocultarDialogo();
    }
    /**
     * Método que decodifica  una imagen en base 64 a bitmap
     * @param encodedString
     * @return bitmap (from given string)
     */
    public Bitmap stringToBitMap(String encodedString){
        try {
            byte [] encodeByte= Base64.decode(encodedString,Base64.DEFAULT);
            Bitmap bitmap= BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.length);
            return bitmap;
        } catch(Exception e) {
            e.getMessage();
            return null;
        }
    }
}

