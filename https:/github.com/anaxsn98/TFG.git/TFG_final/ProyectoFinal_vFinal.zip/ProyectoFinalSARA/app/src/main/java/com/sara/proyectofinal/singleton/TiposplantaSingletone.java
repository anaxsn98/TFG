package com.sara.proyectofinal.singleton;

import com.sara.proyectofinal.modelo.entidad.Tiposplanta;

import java.util.List;

public class TiposplantaSingletone {
    private static TiposplantaSingletone instance;
    private List<Tiposplanta> listaTiposplanta;

    /**
     * Constructor del objeto privado para que nadie entre en la clase,
     * porque si lo hago publico se pueden hacer news del objeto
     */
    private TiposplantaSingletone() {

        super();
    }

    /**
     * getInstance es como los getBeans
     * queremos que nos devuelva la instancia del objeto, no puede ser dinamico
     * tiene que ser estático porque es el método que te devuelve el objeto que es la instancia
     * La primera vez que llamamos al objeto no existe dede el principio del programa
     * Para no sobrecargar la memoria
     * @return instancia de la clase
     */
    public static TiposplantaSingletone getInstance() {
        if (instance == null) {
            instance = new TiposplantaSingletone();
        }
        return instance;
    }

    /**
     * Getter lista plantas
     * @return
     */
    public List<Tiposplanta> getListaTiposplanta() {
        return listaTiposplanta;
    }

    /**
     * Setter lista planta
     * @param listaTiposplanta
     */
    public void setListaTiposplanta(List<Tiposplanta> listaTiposplanta) {
        this.listaTiposplanta = listaTiposplanta;
    }
}
