package com.sara.proyectofinal;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.sara.proyectofinal.modelo.negocio.GestorUsuario;

import java.util.Locale;

public class ForgetPasswordActivity extends AppCompatActivity {
    private ImageView imgEN,imgES;
    private TextView txtRegistrate_inisesion;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);
        imgEN = findViewById(R.id.imgEN);
        imgES = findViewById(R.id.imgES);
        txtRegistrate_inisesion = findViewById(R.id.txtRegistrate_inisesion);

        txtRegistrate_inisesion.setOnClickListener(new View.OnClickListener() {//cambiar de activity
            @Override
            public void onClick(View view) {
                Intent mainActivity = new Intent(ForgetPasswordActivity.this, LoginActivity.class);
                startActivity(mainActivity);
                finish();
            }
        });

        imgEN.setOnClickListener(new View.OnClickListener() {//cambio de idioma
            @Override
            public void onClick(View view) {
                Configuration config = getBaseContext().getResources().getConfiguration();
                Locale locale = new Locale("en","GB");
                Locale.setDefault(locale);
                config.locale = locale;
                getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
                recreate();
            }
        });
        imgES.setOnClickListener(new View.OnClickListener() {//cambio de idioma
            @Override
            public void onClick(View view) {
                Configuration config = getBaseContext().getResources().getConfiguration();
                Locale locale = new Locale("es","ES");
                Locale.setDefault(locale);
                config.locale = locale;
                getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
                recreate();
            }
        });
    }
}