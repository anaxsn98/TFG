package com.sara.proyectofinal.modelo.servicio;

import com.sara.proyectofinal.modelo.entidad.AltaUsuarioDto;
import com.sara.proyectofinal.modelo.entidad.JwtRequest;
import com.sara.proyectofinal.modelo.entidad.JwtResponse;
import com.sara.proyectofinal.modelo.entidad.Planta;
import com.sara.proyectofinal.modelo.entidad.Usuario;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface  GoRestUsuarioApiService {
    //Para poder hacer uso del servicio hay que logarse en la página y generar
    //un token de autenticación, luego hay que incluirlo en la cabecera, dentro
    //del parametros Authorization

    /**
     * Servicio que busca una persona por id
     * @param token token de autrorización
     * @param id id de usuario
     * @return Devuelve el usuario y el codigo de respuesta 200 ok o un 404 not
     * 	       found si no se ha encontrado un usuario con ese id
     */
    @GET("usuarios/{id}")
    Call<Usuario> getPersonaById(@Header("Authorization") String token,
                                                       @Path("id") int id);

    /**
     *  Servicio que hace loguin, que comprueba si el usuairo existe y en caso de que exista en la base
     * 	de datos genera un token de autorización
     * @param usuario datos del usuario
     * @return tipo JwtResponse con token id y nombre de usuario o null en caso de
     * 	       que el usuario sea incorrecto
     */
    @POST("authenticate")
    Call<JwtResponse> login(@Body JwtRequest usuario);

    /**
     *  Da de alta un usuario en la base de datos, si se ha realizado correctamente se genera un token
     * @param usuario datos del usuario
     * @return tipo JwtResponse con token id y nombre de usuario o null en caso de
     * 	       que el usuario sea no se haya podido dar de alta
     */
    @POST("usuarios")
    Call<JwtResponse> altaUsuairo(@Body AltaUsuarioDto usuario);

    /**
     * Servicio que modifica los datos del usuario
     * @param token token de autrorización
     * @param id id de usuario
     * @param usuario usuario con los datos a modificar
     * @return Devuelve el codigo de respuesta 200 ok si se ha modificado el usuario
     * 	       o 404 not found si no se ha encontrado un usuario con ese id
     */
    @PUT("usuarios/{id}")
    Call<Usuario> modificarPersona(@Header("Authorization") String token,
                                 @Path("id") int id, @Body AltaUsuarioDto usuario);

    /**
     * Servicio que elimina de la base de datos un usuario por id eliminando a su vez todas las
     * plantas que tenga asociadas
     * @param token token de autrorización
     * @param id id de usuario
     * @return Devuelve el codigo de respuesta 200 ok si se ha dado de baja el
     * 	       usuario o 404 not found si no se ha encontrado un usuario con ese id
     */
    @DELETE("usuarios/{id}")
    Call<Void> eliminarUsuario(@Header("Authorization") String token,
                              @Path("id") int id);

}
