package com.sara.proyectofinal.modelo.negocio;
import com.google.gson.GsonBuilder;
import com.sara.proyectofinal.modelo.servicio.GoRestTiposplantaApiService;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class GestorTiposplanta {
    private static GestorTiposplanta instance = null;
    private GoRestTiposplantaApiService goRestTiposplantaApiService = null;

    private GestorTiposplanta(){

    }

    public static GestorTiposplanta getInstance(){
        if(instance == null){
            instance = new GestorTiposplanta();
        }
        return instance;
    }
    /**
     * Método que configura Retrofit para acceder al servicio
     */
    public void inicializar(){
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://viernes102-env.eba-ka9t2qtj.us-east-1.elasticbeanstalk.com/")
                .addConverterFactory(GsonConverterFactory.create(
                        new GsonBuilder().serializeNulls().create()
                )).build();

        //Establecemos la relacion entre el servicio y Retrofit
        goRestTiposplantaApiService =
                retrofit.create(GoRestTiposplantaApiService.class);
    }

    public GoRestTiposplantaApiService getGoRestUserApiService(){
        return goRestTiposplantaApiService;
    }
}