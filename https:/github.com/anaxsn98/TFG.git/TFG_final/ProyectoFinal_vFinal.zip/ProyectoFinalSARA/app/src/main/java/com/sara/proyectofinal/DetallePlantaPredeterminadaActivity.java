package com.sara.proyectofinal;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.sara.proyectofinal.databinding.ActivityDetallePlantaBinding;
import com.sara.proyectofinal.modelo.entidad.AltaUsuarioDto;
import com.sara.proyectofinal.modelo.entidad.JwtResponse;
import com.sara.proyectofinal.modelo.entidad.Planta;
import com.sara.proyectofinal.modelo.entidad.Tiposplanta;
import com.sara.proyectofinal.modelo.negocio.GestorPlanta;
import com.sara.proyectofinal.modelo.negocio.GestorUsuario;
import com.sara.proyectofinal.modelo.servicio.GoRestPlantaApiService;
import com.sara.proyectofinal.modelo.servicio.GoRestUsuarioApiService;
import com.sara.proyectofinal.singleton.TiposplantaSingletone;
import com.sara.proyectofinal.singleton.TokenSingletone;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.Inflater;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetallePlantaPredeterminadaActivity extends AppCompatActivity {
    private Tiposplanta tiposplanta;
    private EditText editNombre,editFechaInicio;
    private Button buttonEntrar,buttonAddImg;
    private TextView errorPatronFecha;
    private TokenSingletone tokenSingletone;
    private ProgressDialog mDefaultDialog;
    private ImageView pPredeterminada_imgVegetable,img_calendar;
    private ActivityDetallePlantaBinding binding;
    private ActivityResultLauncher<String> mTakephoto;
    private String img;
    private final Calendar myCalendar= Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDetallePlantaBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        tiposplanta = (Tiposplanta) getIntent().getSerializableExtra("Tiposplanta");
        buttonAddImg = findViewById(R.id.buttonAddImg);
        pPredeterminada_imgVegetable = findViewById(R.id.pPredeterminada_imgVegetable);
        editNombre = findViewById(R.id.editNombre);
        editFechaInicio = findViewById(R.id.editFechaInicio);
        buttonEntrar = findViewById(R.id.buttonEntrar);
        errorPatronFecha = findViewById(R.id.ErrorPatronFecha);
        img_calendar = findViewById(R.id.img_calendar);

        img="";

        pPredeterminada_imgVegetable.setImageBitmap(stringToBitMap(tiposplanta.getImg_url()));

        DatePickerDialog.OnDateSetListener date =new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH,month);
                myCalendar.set(Calendar.DAY_OF_MONTH,day);
                updateLabel();
            }
        };
        img_calendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(DetallePlantaPredeterminadaActivity.this,date,myCalendar
                        .get(Calendar.YEAR),myCalendar.get(Calendar.MONTH),myCalendar
                        .get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        mTakephoto = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri result) {
                        Bitmap bitmap = compressInputImage(result);
                        img = bitMapToString(bitmap);
                        binding.pPredeterminadaImgVegetable.setImageBitmap(bitmap);
                    }
                });

        binding.buttonAddImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mTakephoto.launch("image/*");
            }
        });

        buttonEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Planta planta = new Planta();
                planta.setNombre(editNombre.getText().toString());
                planta.setTiposplanta(tiposplanta);
                if(!comprobarPatronFecha(editFechaInicio.getText().toString())){
                    respuestaError();
                    return;
                }
                planta.setFechaIni(editFechaInicio.getText().toString());
                if(img != "") //en caso de que el usuario haya subido una foto
                    planta.setImg(img);
                if(tiposplanta.getId_tipoplanta() == 1 || tiposplanta.getId_tipoplanta() == 2
                        ||tiposplanta.getId_tipoplanta() == 3 ){//si es una planta predeterminada
                    registroPlanta(planta);
                }else{
                    //ir a la siguiente pantalla
                    Intent intent = new Intent(DetallePlantaPredeterminadaActivity.this,
                            ConfiguracionPlantaPersonalizadaActivity.class);
                    intent.putExtra("Planta", planta);
                    startActivity(intent);
                    finish();
                }
            }
        });
    }

    /**
     * Pone en el edittext la fecha seleccionada en el calendario con el formato dd/MM/yyyy
     */
    private void updateLabel(){
        String myFormat="dd/MM/yyyy";
        SimpleDateFormat dateFormat=new SimpleDateFormat(myFormat, Locale.ENGLISH);
        editFechaInicio.setText(dateFormat.format(myCalendar.getTime()));
    }

    /**
     * Método para mostrar un mensaje de error durante 5 segundos
     */
    public void respuestaError(){
        new CountDownTimer(5000, 1000) {

            public void onTick(long millisUntilFinished) {
                errorPatronFecha.setText("Fecha incorrecta. Introduce dd/mm/yyyy");
            }

            @Override
            public void onFinish() {
                errorPatronFecha.setText("");
            }

        }.start();
    }

    /**
     * Método que comprueba que el edittext tiene el patrón de fecha correcto
     * @param fecha string con la fecha
     * @return true si se ha seguido el patron false en caso contrario
     */
    public boolean comprobarPatronFecha(String fecha){
        Pattern pat = Pattern.compile("^([0-2][0-9]|3[0-1])(\\/|-)(0[1-9]|1[0-2])\\2(\\d{4})$");
        Matcher mat = pat.matcher(fecha);
        if (mat.find()) {
            return true;
        }
        return false;
    }

    /**
     * Llamada al servicio para dar de alta una planta
     * @param p planta que se quiere dar de alta
     */
    public void registroPlanta(Planta p){
        mostrarEspera();

        GoRestPlantaApiService goRestPlantaApiService =
                GestorPlanta.getInstance().getGoRestPlantaApiService();
        tokenSingletone = TokenSingletone.getInstance();

        Call<Planta> call = goRestPlantaApiService.altaPlanta(tokenSingletone.getToken(),tokenSingletone.getId(),p);

        call.enqueue(new Callback<Planta>() {
            //Este método se ejecutará cuando el servidor HTTP nos responda
            //satisfactoriamente
            @Override
            public void onResponse(Call<Planta> call, Response<Planta> response) {
                if (response.isSuccessful()) {
                    cancelarEspera();

                    Intent mainActivity = new Intent(DetallePlantaPredeterminadaActivity.this, MainActivity.class);
                    startActivity(mainActivity);
                    finish();
                } else {
                    Log.d("Alta planta", response.code() + " " + response.message());
                    return;
                }

                cancelarEspera();
            }

            @Override
            public void onFailure(Call<Planta> call, Throwable t) {
                Log.d("Alta planta", t.toString());
                cancelarEspera();
            }
        });
    }
    /**
     * Método que muestra un dialogo personalizado
     */
    public void mostrarEspera() {
        mDefaultDialog = new ProgressDialog(this);
        // El valor predeterminado es la forma de círculos pequeños
        mDefaultDialog.setProgressStyle (ProgressDialog.STYLE_SPINNER);
        mDefaultDialog.setMessage("Solicitando datos ...");
        mDefaultDialog.setCanceledOnTouchOutside(false);// Por defecto true
        mDefaultDialog.show();
    }

    /**
     * Método que termina con el dialogo
     */
    public void cancelarEspera(){
        mDefaultDialog.cancel();
    }

    /**
     * Método que convierte un bitmap a base 64
     * @param bitmap imagen en bitmap
     * @return imagen convertida en base 64
     */
    public String bitMapToString(Bitmap bitmap){
        ByteArrayOutputStream baos=new  ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG,100, baos);
        byte [] b=baos.toByteArray();
        String temp= Base64.encodeToString(b, Base64.DEFAULT);
        return temp;
    }

    /**
     * Comprime una imagen a bitmap
     * @param inputImageData imagen
     * @return imagen convertida en bitmap
     */
    public  Bitmap compressInputImage(Uri inputImageData)
    {
        Bitmap dpBitmap = null,bitmapInputImage = null;
        try
        {
            bitmapInputImage = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), inputImageData);

            dpBitmap = Bitmap.createScaledBitmap(bitmapInputImage, 240, 140, true);


        } catch (Exception e)
        {
            dpBitmap = bitmapInputImage;
        }
        return dpBitmap;
    }

    /**
     * Método que decodifica una imagen en base 64 a bitmap
     * @param encodedString
     * @return bitmap (from given string)
     */
    public Bitmap stringToBitMap(String encodedString){
        try {
            byte [] encodeByte= Base64.decode(encodedString,Base64.DEFAULT);
            Bitmap bitmap= BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.length);
            return bitmap;
        } catch(Exception e) {
            e.getMessage();
            return null;
        }
    }

    /**
     * Este método es llamado luego de onCreate().
     *
     * Comprueba el idioma seleccionado en la aplicación y lo aplica en la vista correspondiente
     */
    @Override
    protected void onStart() {
        super.onStart();
        Log.d("MainActivity", "onStart()");
        Configuration config = getBaseContext().getResources().getConfiguration();
        Locale locale = getResources().getConfiguration().locale;
        Locale.setDefault(locale);
        config.locale = locale;
        getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
    }
}