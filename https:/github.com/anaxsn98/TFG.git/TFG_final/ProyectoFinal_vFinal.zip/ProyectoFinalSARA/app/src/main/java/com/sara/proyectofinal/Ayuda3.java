package com.sara.proyectofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Ayuda3 extends AppCompatActivity {
    private Button btnAyuda3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ayuda3);
        btnAyuda3 = findViewById(R.id.btnAyuda3);
        btnAyuda3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent( getApplicationContext(),Ayuda4.class);
                startActivity(intent);
                finish();
            }
        });
    }
}