package com.sara.proyectofinal;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.sara.proyectofinal.modelo.negocio.GestorPlanta;
import com.sara.proyectofinal.modelo.servicio.GoRestPlantaApiService;
import com.sara.proyectofinal.singleton.TokenSingletone;

import java.util.Calendar;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Fragment_estado#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Fragment_estado extends Fragment {
    private View vista;
    private ProgressBar progressBarAgua, progressBarLuz, progressBarVentilacion;
    private TextView txtPorcentajeVentilacion,txtPorcentajeLuz,txtPorcentajeAgua;
    private DialogoGif dialogoGif;
    private TokenSingletone tokenSingletone;
    private List<Integer> progress;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Fragment_estado() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Fragment_estado.
     */
    // TODO: Rename and change types and number of parameters
    public static Fragment_estado newInstance(String param1, String param2) {
        Fragment_estado fragment = new Fragment_estado();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        vista = inflater.inflate(R.layout.fragment_estado, container, false);

        getProgressBar();

        progressBarAgua = vista.findViewById(R.id.porcentajeAgua);
        progressBarLuz = vista.findViewById(R.id.porcentajeLuz);
        progressBarVentilacion = vista.findViewById(R.id.porcentajeVentilacion);
        txtPorcentajeVentilacion = vista.findViewById(R.id.txtPorcentajeVentilacion);
        txtPorcentajeLuz = vista.findViewById(R.id.txtPorcentajeLuz);
        txtPorcentajeAgua = vista.findViewById(R.id.txtPorcentajeAgua);

        if(progress != null) {//dar valor al progressbar
            getProgressBarLuz(progress.get(0));
            getProgressBarAgua(progress.get(1));
            getProgressBarVentilacion(progress.get(2));
        }
        return vista;
    }


    /**
     * Método que recoge el estado del agua y muestra el porcentaje del agua
     * en una progressbar
     * @param progress la cantidad de agua en porcentaje
     */
    public void getProgressBarAgua(int progress) {
        progressBarAgua.setProgress(progress);
        txtPorcentajeAgua.setText(Integer.toString(progress)+"%");
    }

    /**
     * Método que recoge el estado del agua y muestra el porcentaje del agua
     * en una progressbar
     * @param progress la cantidad de agua en porcentaje
     */
    public void getProgressBarLuz(int progress) {
        progressBarLuz.setProgress(progress);
        txtPorcentajeLuz.setText(Integer.toString(progress)+"%");
    }



    /**
     * Método que recoge el estado del agua y muestra el porcentaje del agua
     * en una progressbar
     * @param progress la cantidad de agua en porcentaje
     */
    public void getProgressBarVentilacion(int progress) {
        progressBarVentilacion.setProgress(progress);
        txtPorcentajeVentilacion.setText(Integer.toString(progress)+"%");
    }

    /**
     * Servicio que recoge los porcentajes de cada evento
     */
    public void getProgressBar(){
        mostrarEspera();
        tokenSingletone = TokenSingletone.getInstance();
        System.out.println(tokenSingletone);
        GoRestPlantaApiService goRestPlantaApiService =
                GestorPlanta.getInstance().getGoRestPlantaApiService();

        Call<List<Integer>> call = goRestPlantaApiService.getProgressBar(tokenSingletone.getToken(), tokenSingletone.getId());

        call.enqueue(new Callback<List<Integer>>() {
            //Este método se ejecutará cuando el servidor HTTP nos responda
            //satisfactoriamente
            @Override
            public void onResponse(Call<List<Integer>> call, Response<List<Integer>> response) {
                if (response.isSuccessful()) {
                    Log.d("Eventos Planta Actual", "busqueda hecha");
                    progress = response.body();
                    for (int i: progress
                    ) {
                       System.out.println(i);
                    }
                    if(progress != null && progress.size()>0){
                        getProgressBarAgua(progress.get(0));
                        getProgressBarLuz(progress.get(1));
                        getProgressBarVentilacion(progress.get(2));
                    }
                } else {

                    cancelarEspera();

                }

                cancelarEspera();
            }

            @Override
            public void onFailure(Call<List<Integer>> call, Throwable t) {
                Log.d("Eventos Planta Actual", t.toString());
                cancelarEspera();

            }
        });
    }
    /**
     * Método que muestra un dialogo personalizado
     */
    public void mostrarEspera() {
        dialogoGif = new DialogoGif();
        dialogoGif.setContext(getActivity());
        dialogoGif.mostrarDialogo();
    }

    /**
     * Método que termina con el dialogo
     */
    public void cancelarEspera(){
        dialogoGif.ocultarDialogo();
    }
    private void setToMidnight(Calendar calendar) {
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
    }
}