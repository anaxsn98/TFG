package es.uem.seguridad.jwt;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import es.uem.seguridad.jwt.modelo.JwtRequest;
import es.uem.seguridad.jwt.modelo.JwtResponse;
import es.uem.usuario.dto.AltaUsuarioDto;
import es.uem.usuario.modelo.Usuario;
import es.uem.usuario.negocio.GestorUsuario;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;

@RestController
public class AuthenticationController {
	@Autowired
	private AuthenticationManager authenticationManager;
	@Autowired
	private JwtTokenProvider tokenProvider;
	@Autowired
	private GestorUsuario gestorUsuario;
	@Autowired
	private PasswordEncoder passwordEncoder;

	/**
	 * Método que comprueba si el usuairo existe y en caso de que exista en la base
	 * de datos genera un token de autorización
	 * 
	 * @param authenticationRequest datos para hacer login del usuario
	 * @return tipo JwtResponse con token id y nombre de usuario o null en caso de
	 *         que el usuario sea incorrecto
	 */
	@PostMapping(path = "/authenticate", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public JwtResponse login(@RequestBody JwtRequest authenticationRequest) {

		try {
			authenticate(authenticationRequest.getUsername(), authenticationRequest.getPassword());
		} catch (Exception e) {
			e.printStackTrace();
		}

		final UserDetails userDetails = gestorUsuario.loadUserByUsername(authenticationRequest.getUsername());

		Usuario user = gestorUsuario.findUsuarioByNombre(authenticationRequest.getUsername());

		if (user == null)
			user = gestorUsuario.findUsuarioByCorreo(authenticationRequest.getUsername());

		if (user == null)
			return null;

		if (!passwordEncoder.matches(authenticationRequest.getPassword(), user.getPwd())) {
			return null;
		}

		final String token = tokenProvider.generateToken(userDetails, user.getId());

		return new JwtResponse(token, Integer.toString(user.getId()), user.getNombre());
	}

	/**
	 * Método que autentifica a una persona
	 * @param username nombre de usuario
	 * @param password contraseña de usuario
	 * @throws Exception
	 */
	private void authenticate(String username, String password) throws Exception {
		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
		} catch (DisabledException e) {
			throw new Exception("USER_DISABLED", e);
		} catch (BadCredentialsException e) {
			throw new Exception("INVALID_CREDENTIALS", e);
		}
	}

	/**
	 * Da de alta un usuario en la base de datos, si se ha realizado correctamente se genera un token
	 * @param u objeto AltaUsuarioDto con datos de alta del usuario
	 * @return tipo JwtResponse con token id y nombre de usuario o null en caso de
	 *         que el usuario sea incorrecto
	 */
	@PostMapping(path = "usuarios", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public JwtResponse altaPersona(@RequestBody AltaUsuarioDto u) {
		if (gestorUsuario.altaUsuairo(u)) {
			System.out.println("dado de alta");
			try {
				authenticate(u.getNombre(), u.getPwd());
			} catch (Exception e) {
				e.printStackTrace();
			}

			final UserDetails userDetails = gestorUsuario.loadUserByUsername(u.getNombre());
			Usuario user = gestorUsuario.findUsuarioByNombre(u.getNombre());

			final String token = tokenProvider.generateToken(userDetails, user.getId());

			return new JwtResponse(token, Integer.toString(user.getId()), user.getNombre());
		}
		System.out.println("no dado de alta");
		return null;
	}
}