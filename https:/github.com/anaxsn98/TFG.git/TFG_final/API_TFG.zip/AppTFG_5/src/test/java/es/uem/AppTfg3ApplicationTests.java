package es.uem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppTfg3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
